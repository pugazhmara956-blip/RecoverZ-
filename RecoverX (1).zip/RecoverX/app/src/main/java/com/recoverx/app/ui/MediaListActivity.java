package com.recoverx.app.ui;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.chip.ChipGroup;
import com.recoverx.app.R;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.data.Prefs;
import com.recoverx.app.data.PreservedMedia;
import com.recoverx.app.media.MediaExporter;
import com.recoverx.app.util.AppUtils;

import java.util.List;

/** One media page, for example "Deleted Photos". Shows removed files by default; "All saved" shows every copy. */
public class MediaListActivity extends AppCompatActivity implements DatabaseHelper.ChangeListener {

    private static final String EXTRA_CATEGORY = "category";
    private static final long DAY_MS = 24L * 60 * 60 * 1000;

    private MediaCategory category;
    private MediaAdapter adapter;
    private TextView resultsCount;
    private View emptyBox;
    private TextView emptyText;
    private View emptySetup;

    private boolean deletedOnly = true;
    private String packageName;
    private Long fromMillis;
    private String query = "";

    private final ActivityResultLauncher<Uri> exportPicker = registerForActivityResult(
            new ActivityResultContracts.OpenDocumentTree(), this::exportTo);

    public static Intent intent(Context c, MediaCategory category) {
        return new Intent(c, MediaListActivity.class).putExtra(EXTRA_CATEGORY, category.name());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media_list);
        category = MediaCategory.fromName(getIntent().getStringExtra(EXTRA_CATEGORY));
        UiHelper.setupToolbar(this, category.deletedTitleRes);

        resultsCount = findViewById(R.id.results_count);
        emptyBox = findViewById(R.id.empty_box);
        emptyText = findViewById(R.id.empty_text);
        emptySetup = findViewById(R.id.btn_empty_setup);
        emptySetup.setOnClickListener(v -> startActivity(new Intent(this, MediaSetupActivity.class)));

        RecyclerView list = findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(this));
        adapter = new MediaAdapter(m -> startActivity(MediaViewerActivity.intent(this, m.id)));
        list.setAdapter(adapter);

        EditText search = findViewById(R.id.search_box);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                query = s.toString();
                reload();
            }
        });

        UiHelper.bindChips(this, findViewById(R.id.status_chips),
                new String[]{getString(R.string.filter_removed), getString(R.string.filter_all_saved)},
                new Object[]{Boolean.TRUE, Boolean.FALSE}, 0, tag -> {
                    deletedOnly = Boolean.TRUE.equals(tag);
                    reload();
                });
        ChipGroup apps = findViewById(R.id.app_chips);
        UiHelper.bindAppChips(this, apps, Prefs.MEDIA_FOLDER_PACKAGES, tag -> {
            packageName = (String) tag;
            reload();
        });
        UiHelper.bindChips(this, findViewById(R.id.date_chips),
                new String[]{getString(R.string.date_any), getString(R.string.date_today), getString(R.string.date_7), getString(R.string.date_30)},
                new Object[]{null, 0, 7, 30}, 0, tag -> {
                    if (tag == null) fromMillis = null;
                    else {
                        int days = (Integer) tag;
                        fromMillis = AppUtils.startOfToday() - days * DAY_MS;
                    }
                    reload();
                });

        findViewById(R.id.btn_export_all).setOnClickListener(v -> {
            if (adapter.getItemCount() == 0) {
                Toast.makeText(this, R.string.nothing_to_export, Toast.LENGTH_SHORT).show();
            } else {
                exportPicker.launch(null);
            }
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        DatabaseHelper.addListener(this);
        reload();
    }

    @Override
    protected void onStop() {
        DatabaseHelper.removeListener(this);
        super.onStop();
    }

    @Override
    public void onDataChanged() {
        reload();
    }

    private void reload() {
        final Context app = getApplicationContext();
        final DatabaseHelper.MediaFilter f = new DatabaseHelper.MediaFilter();
        f.mediaTypes = category.types;
        f.deletedOnly = deletedOnly;
        f.packageName = packageName;
        f.fromMillis = fromMillis;
        f.senderQuery = query;
        AppUtils.background(() -> DatabaseHelper.get(app).queryMedia(f), (List<PreservedMedia> list) -> {
            if (isFinishing()) return;
            adapter.submit(list);
            resultsCount.setText(getResources().getQuantityString(R.plurals.files_count, list.size(), list.size()));
            boolean empty = list.isEmpty();
            emptyBox.setVisibility(empty ? View.VISIBLE : View.GONE);
            boolean ready = Prefs.isCaptureMedia(app) && Prefs.hasAnyMediaTree(app);
            emptySetup.setVisibility(empty && !ready ? View.VISIBLE : View.GONE);
            if (!ready) emptyText.setText(R.string.media_empty_not_setup);
            else if (deletedOnly) emptyText.setText(R.string.media_empty_removed);
            else emptyText.setText(R.string.media_empty_saved);
        }, null);
    }

    private void exportTo(Uri tree) {
        if (tree == null) return;
        final Context app = getApplicationContext();
        final List<PreservedMedia> items = adapter.getItems();
        Toast.makeText(this, R.string.exporting, Toast.LENGTH_SHORT).show();
        AppUtils.background(() -> MediaExporter.exportToTree(app, tree, items),
                saved -> Toast.makeText(app, getResources().getQuantityString(R.plurals.exported_count, saved, saved), Toast.LENGTH_LONG).show(),
                e -> Toast.makeText(app, R.string.export_failed, Toast.LENGTH_LONG).show());
    }
}
