package com.recoverx.app.ui;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.recoverx.app.R;

/** Deleted text messages page (possibly deleted or marked by the user). */
public class DeletedTextActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deleted_text);
        UiHelper.setupToolbar(this, R.string.cat_text_deleted);
        if (savedInstanceState == null) {
            DeletedFragment f = new DeletedFragment();
            Bundle args = new Bundle();
            args.putBoolean(BaseListFragment.ARG_EMBEDDED, true);
            f.setArguments(args);
            getSupportFragmentManager().beginTransaction().replace(R.id.fragment_container, f).commit();
        }
    }
}
