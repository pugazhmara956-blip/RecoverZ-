package com.recoverx.app.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.recoverx.app.R;
import com.recoverx.app.data.CapturedMessage;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.util.AppUtils;

import java.util.List;

/** Shared logic for the Messages and Deleted screens. */
public abstract class BaseListFragment extends Fragment implements DatabaseHelper.ChangeListener {

    /** When true the screen sits inside an activity with its own toolbar, so the header title is hidden. */
    public static final String ARG_EMBEDDED = "embedded";

    protected View root;
    private MessageAdapter adapter;
    private TextView emptyText;

    protected abstract int layoutRes();

    protected abstract int titleRes();

    protected abstract int emptyRes();

    /** Builds the filter for the current search and type selection. */
    protected abstract DatabaseHelper.Filter buildFilter();

    /** Called after the view is created, for screen-specific controls. */
    protected void onViewReady() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(layoutRes(), container, false);
        ((TextView) root.findViewById(R.id.list_title)).setText(titleRes());
        emptyText = root.findViewById(R.id.empty_text);
        RecyclerView list = root.findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new MessageAdapter(m -> UiHelper.showMessageDetail(requireActivity(), m));
        list.setAdapter(adapter);
        root.findViewById(R.id.btn_header_search).setOnClickListener(v -> startActivity(new Intent(requireContext(), SearchActivity.class)));
        root.findViewById(R.id.btn_header_clear).setOnClickListener(v -> confirmClearAll());
        if (getArguments() != null && getArguments().getBoolean(ARG_EMBEDDED)) {
            root.findViewById(R.id.list_title).setVisibility(View.INVISIBLE);
        }
        onViewReady();
        return root;
    }

    @Override
    public void onStart() {
        super.onStart();
        DatabaseHelper.addListener(this);
        reload();
    }

    @Override
    public void onStop() {
        DatabaseHelper.removeListener(this);
        super.onStop();
    }

    @Override
    public void onDataChanged() {
        reload();
    }

    protected void reload() {
        if (root == null) return;
        final Context app = requireContext().getApplicationContext();
        final DatabaseHelper.Filter filter = buildFilter();
        AppUtils.background(() -> DatabaseHelper.get(app).query(filter), (List<CapturedMessage> list) -> {
            if (!isAdded()) return;
            adapter.submit(list);
            boolean empty = list.isEmpty();
            emptyText.setVisibility(empty ? View.VISIBLE : View.GONE);
            emptyText.setText(hasActiveFilter() ? R.string.no_results : emptyRes());
        }, null);
    }

    protected boolean hasActiveFilter() {
        return false;
    }

    private void confirmClearAll() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.clear_all_title)
                .setMessage(R.string.clear_all_body)
                .setPositiveButton(R.string.delete, (d, w) -> {
                    final Context app = requireContext().getApplicationContext();
                    AppUtils.background(() -> {
                        DatabaseHelper.get(app).clearAll();
                        return true;
                    }, r -> Toast.makeText(app, R.string.cleared, Toast.LENGTH_SHORT).show(), null);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
