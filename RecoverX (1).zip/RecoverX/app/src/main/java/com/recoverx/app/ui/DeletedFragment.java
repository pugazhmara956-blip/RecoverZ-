package com.recoverx.app.ui;

import com.recoverx.app.R;
import com.recoverx.app.data.DatabaseHelper;

/**
 * Deleted-message records: messages flagged as possibly deleted (WhatsApp later showed
 * "This message was deleted" in the same chat) and messages the user marked as deleted.
 */
public class DeletedFragment extends BaseListFragment {

    @Override
    protected int layoutRes() {
        return R.layout.fragment_deleted;
    }

    @Override
    protected int titleRes() {
        return R.string.deleted_title;
    }

    @Override
    protected int emptyRes() {
        return R.string.no_deleted;
    }

    @Override
    protected DatabaseHelper.Filter buildFilter() {
        DatabaseHelper.Filter f = new DatabaseHelper.Filter();
        f.deletedOnly = true;
        return f;
    }
}
