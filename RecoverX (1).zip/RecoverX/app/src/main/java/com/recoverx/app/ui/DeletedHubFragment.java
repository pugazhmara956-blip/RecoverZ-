package com.recoverx.app.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.recoverx.app.R;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.data.Prefs;
import com.recoverx.app.media.MediaScanner;
import com.recoverx.app.util.AppUtils;

import java.util.EnumMap;
import java.util.Map;

/** Entry point to the six deleted-content pages. */
public class DeletedHubFragment extends Fragment implements DatabaseHelper.ChangeListener {

    private View root;
    private final Map<MediaCategory, View> rows = new EnumMap<>(MediaCategory.class);

    private static class Counts {
        final Map<MediaCategory, long[]> media = new EnumMap<>(MediaCategory.class);
        long[] text;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_deleted_hub, container, false);
        LinearLayout holder = root.findViewById(R.id.media_categories);
        for (MediaCategory cat : MediaCategory.values()) {
            View row = inflater.inflate(R.layout.item_category, holder, false);
            ((ImageView) row.findViewById(R.id.cat_icon)).setImageResource(cat.iconRes);
            ((TextView) row.findViewById(R.id.cat_title)).setText(cat.deletedTitleRes);
            row.setOnClickListener(v -> startActivity(MediaListActivity.intent(requireContext(), cat)));
            holder.addView(row);
            rows.put(cat, row);
        }
        View text = root.findViewById(R.id.cat_text);
        ((ImageView) text.findViewById(R.id.cat_icon)).setImageResource(R.drawable.ic_message);
        ((TextView) text.findViewById(R.id.cat_title)).setText(R.string.cat_text_deleted);
        text.setOnClickListener(v -> startActivity(new Intent(requireContext(), DeletedTextActivity.class)));

        root.findViewById(R.id.btn_setup_media).setOnClickListener(v -> openSetup());
        root.findViewById(R.id.btn_media_settings).setOnClickListener(v -> openSetup());
        return root;
    }

    private void openSetup() {
        startActivity(new Intent(requireContext(), MediaSetupActivity.class));
    }

    @Override
    public void onStart() {
        super.onStart();
        DatabaseHelper.addListener(this);
    }

    @Override
    public void onResume() {
        super.onResume();
        Context c = requireContext();
        boolean ready = Prefs.isCaptureMedia(c) && Prefs.hasAnyMediaTree(c);
        root.findViewById(R.id.setup_card).setVisibility(ready ? View.GONE : View.VISIBLE);
        ((TextView) root.findViewById(R.id.last_scan)).setText(MediaScanner.lastScanText(c));
        load();
    }

    @Override
    public void onStop() {
        DatabaseHelper.removeListener(this);
        super.onStop();
    }

    @Override
    public void onDataChanged() {
        load();
    }

    private void load() {
        final Context app = requireContext().getApplicationContext();
        AppUtils.background(() -> {
            DatabaseHelper db = DatabaseHelper.get(app);
            Counts counts = new Counts();
            for (MediaCategory cat : MediaCategory.values()) counts.media.put(cat, db.mediaCounts(cat.types));
            counts.text = db.textDeletedCounts();
            return counts;
        }, counts -> {
            if (!isAdded()) return;
            for (Map.Entry<MediaCategory, View> e : rows.entrySet()) {
                long[] c = counts.media.get(e.getKey());
                bindCounts(e.getValue(), c == null ? new long[]{0, 0} : c, R.string.media_counts);
            }
            bindCounts(root.findViewById(R.id.cat_text), counts.text, R.string.text_counts);
        }, null);
    }

    private void bindCounts(View row, long[] c, int formatRes) {
        ((TextView) row.findViewById(R.id.cat_counts)).setText(getString(formatRes, c[0], c[1]));
        TextView badge = row.findViewById(R.id.cat_badge);
        badge.setVisibility(c[0] > 0 ? View.VISIBLE : View.GONE);
        badge.setText(String.valueOf(c[0]));
    }
}
