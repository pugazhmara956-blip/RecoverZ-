package com.recoverx.app.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.OvershootInterpolator;

import androidx.appcompat.app.AppCompatActivity;

import com.recoverx.app.R;
import com.recoverx.app.data.Prefs;
import com.recoverx.app.util.AppUtils;

/** Animated splash screen, then onboarding (first launch), setup or the dashboard. */
@SuppressLint("CustomSplashScreen")
public class SplashActivity extends AppCompatActivity {

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable next = this::goNext;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        View logo = findViewById(R.id.splash_logo);
        View name = findViewById(R.id.splash_name);
        View tagline = findViewById(R.id.splash_tagline);
        logo.setScaleX(0.4f);
        logo.setScaleY(0.4f);
        logo.setAlpha(0f);
        logo.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(700).setInterpolator(new OvershootInterpolator()).start();
        name.setAlpha(0f);
        name.setTranslationY(30f);
        name.animate().alpha(1f).translationY(0f).setStartDelay(300).setDuration(500).start();
        tagline.setAlpha(0f);
        tagline.animate().alpha(1f).setStartDelay(600).setDuration(500).start();

        handler.postDelayed(next, 1600);
    }

    private void goNext() {
        Class<?> target;
        if (!Prefs.isOnboarded(this)) target = OnboardingActivity.class;
        else if (!AppUtils.hasNotificationAccess(this)) target = SetupActivity.class;
        else target = MainActivity.class;
        startActivity(new Intent(this, target));
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        finish();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(next);
        super.onDestroy();
    }
}
