package com.recoverx.app.media;

import android.content.Context;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.recoverx.app.data.Prefs;

import java.util.concurrent.TimeUnit;

public final class MediaScheduler {
    private static final String PERIODIC = "media_scan_periodic";
    private static final String SOON = "media_scan_soon";

    private MediaScheduler() {
    }

    /** Starts or stops the periodic scan to match the current settings. */
    public static void sync(Context context) {
        WorkManager wm = WorkManager.getInstance(context.getApplicationContext());
        if (Prefs.isCaptureMedia(context) && Prefs.hasAnyMediaTree(context)) {
            Constraints constraints = new Constraints.Builder().setRequiresStorageNotLow(true).build();
            PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(MediaScanWorker.class, 15, TimeUnit.MINUTES)
                    .setConstraints(constraints).build();
            wm.enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.KEEP, req);
        } else {
            wm.cancelUniqueWork(PERIODIC);
            wm.cancelUniqueWork(SOON);
        }
    }

    /** Called when a media notification arrives: scan shortly after, so a downloaded file is copied quickly. */
    public static void scanSoon(Context context) {
        if (!Prefs.isCaptureMedia(context) || !Prefs.hasAnyMediaTree(context)) return;
        OneTimeWorkRequest req = new OneTimeWorkRequest.Builder(MediaScanWorker.class)
                .setInitialDelay(45, TimeUnit.SECONDS).build();
        WorkManager.getInstance(context.getApplicationContext()).enqueueUniqueWork(SOON, ExistingWorkPolicy.REPLACE, req);
    }
}
