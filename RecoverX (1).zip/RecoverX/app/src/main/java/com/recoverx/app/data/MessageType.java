package com.recoverx.app.data;

import com.recoverx.app.R;

import java.util.Locale;

/** Message types, detected from the label WhatsApp puts in the notification text. */
public final class MessageType {
    public static final String TEXT = "TEXT";
    public static final String IMAGE = "IMAGE";
    public static final String VIDEO = "VIDEO";
    public static final String AUDIO = "AUDIO";
    public static final String VOICE = "VOICE";
    public static final String GIF = "GIF";
    public static final String DOCUMENT = "DOCUMENT";
    public static final String STICKER = "STICKER";
    public static final String OTHER = "OTHER";
    public static final String HIDDEN = "HIDDEN";

    public static final String[] ALL = {TEXT, IMAGE, VIDEO, VOICE, AUDIO, DOCUMENT, GIF, STICKER, OTHER, HIDDEN};

    private MessageType() {
    }

    /**
     * Detects the type from notification labels, for example WhatsApp's "Photo" or
     * "Voice message (0:12)" (often with an emoji in front) and Instagram's "sent you a photo".
     */
    public static String detect(String text) {
        if (text == null) return TEXT;
        String t = text.trim();
        String lower = t.toLowerCase(Locale.ENGLISH);
        // WhatsApp labels: camera, video camera, movie camera, microphone, music note, page emoji
        if (t.startsWith("\uD83D\uDCF7") || lower.equals("photo") || lower.startsWith("photo ")) return IMAGE;
        if (t.startsWith("\uD83C\uDFA5") || t.startsWith("\uD83D\uDCF9") || lower.equals("video") || lower.startsWith("video ")) return VIDEO;
        if (t.startsWith("\uD83C\uDFA4") || lower.startsWith("voice message")) return VOICE;
        if (t.startsWith("\uD83C\uDFB5") || lower.equals("audio") || lower.startsWith("audio ")) return AUDIO;
        if (t.startsWith("\uD83D\uDCC4") || lower.startsWith("document") || lower.endsWith(".pdf")) return DOCUMENT;
        if (lower.equals("gif") || lower.startsWith("gif ") || lower.endsWith(" gif")) return GIF;
        if (lower.equals("sticker") || t.startsWith("\uD83D\uDC7E")) return STICKER;
        // Location pin, person and bar chart emoji, or the words
        if (t.startsWith("\uD83D\uDCCD") || t.startsWith("\uD83D\uDC64") || t.startsWith("\uD83D\uDCCA")
                || lower.startsWith("location") || lower.startsWith("contact") || lower.startsWith("poll")) return OTHER;
        // Instagram direct message labels
        if (lower.contains("sent you a photo") || lower.contains("sent a photo")) return IMAGE;
        if (lower.contains("sent you a video") || lower.contains("sent a video") || lower.contains("sent a reel")) return VIDEO;
        if (lower.contains("sent you a voice message") || lower.contains("sent a voice message")) return VOICE;
        if (lower.contains("sent you a gif") || lower.contains("sent a gif")) return GIF;
        if (lower.contains("sent an attachment") || lower.contains("sent you an attachment")) return OTHER;
        if (lower.equals("new message") || lower.matches("^\\d+ new messages?$")) return HIDDEN;
        return TEXT;
    }

    public static boolean isMedia(String type) {
        return IMAGE.equals(type) || VIDEO.equals(type) || AUDIO.equals(type) || VOICE.equals(type)
                || DOCUMENT.equals(type) || GIF.equals(type);
    }

    public static int label(String type) {
        if (IMAGE.equals(type)) return R.string.type_image;
        if (VIDEO.equals(type)) return R.string.type_video;
        if (AUDIO.equals(type)) return R.string.type_audio;
        if (VOICE.equals(type)) return R.string.type_voice;
        if (GIF.equals(type)) return R.string.type_gif;
        if (DOCUMENT.equals(type)) return R.string.type_document;
        if (STICKER.equals(type)) return R.string.type_sticker;
        if (OTHER.equals(type)) return R.string.type_other;
        if (HIDDEN.equals(type)) return R.string.type_hidden;
        return R.string.type_text;
    }
}
