package com.recoverx.app.ui;

import com.recoverx.app.R;
import com.recoverx.app.data.MessageType;

/** The media pages shown on the Deleted screen. */
public enum MediaCategory {
    PHOTOS(R.string.cat_photos, R.string.cat_photos_deleted, R.drawable.ic_image, new String[]{MessageType.IMAGE}),
    VIDEOS(R.string.cat_videos, R.string.cat_videos_deleted, R.drawable.ic_video, new String[]{MessageType.VIDEO, MessageType.GIF}),
    AUDIO(R.string.cat_audio, R.string.cat_audio_deleted, R.drawable.ic_audio, new String[]{MessageType.AUDIO}),
    VOICE(R.string.cat_voice, R.string.cat_voice_deleted, R.drawable.ic_mic, new String[]{MessageType.VOICE}),
    DOCUMENTS(R.string.cat_documents, R.string.cat_documents_deleted, R.drawable.ic_document, new String[]{MessageType.DOCUMENT});

    public final int labelRes;
    public final int deletedTitleRes;
    public final int iconRes;
    public final String[] types;

    MediaCategory(int labelRes, int deletedTitleRes, int iconRes, String[] types) {
        this.labelRes = labelRes;
        this.deletedTitleRes = deletedTitleRes;
        this.iconRes = iconRes;
        this.types = types;
    }

    public static MediaCategory forType(String type) {
        for (MediaCategory c : values()) for (String t : c.types) if (t.equals(type)) return c;
        return DOCUMENTS;
    }

    public static MediaCategory fromName(String name) {
        try {
            return valueOf(name);
        } catch (Exception e) {
            return PHOTOS;
        }
    }
}
