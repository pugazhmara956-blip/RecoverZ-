package com.recoverx.app.media;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.MediaStore;

import com.recoverx.app.data.MessageType;
import com.recoverx.app.data.PreservedMedia;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/** Saves copies to places the user chooses. Nothing is uploaded. */
public final class MediaExporter {
    private MediaExporter() {
    }

    public static boolean canSaveToPhone() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q;
    }

    /** Android 10+: saves into Pictures, Movies, Music or Download under a RecoverX folder. No permission needed. */
    public static String saveToPhone(Context context, PreservedMedia m) throws IOException {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) throw new IOException("Use Export on this Android version");
        ContentResolver cr = context.getContentResolver();
        Uri collection;
        String dir;
        String type = m.mediaType;
        if (MessageType.IMAGE.equals(type) || MessageType.GIF.equals(type) && m.mimeType != null && m.mimeType.startsWith("image/")) {
            collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            dir = Environment.DIRECTORY_PICTURES;
        } else if (MessageType.VIDEO.equals(type) || MessageType.GIF.equals(type)) {
            collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            dir = Environment.DIRECTORY_MOVIES;
        } else if (MessageType.AUDIO.equals(type) || MessageType.VOICE.equals(type)) {
            collection = MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            dir = Environment.DIRECTORY_MUSIC;
        } else {
            collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY);
            dir = Environment.DIRECTORY_DOWNLOADS;
        }
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, m.fileName);
        if (m.mimeType != null) cv.put(MediaStore.MediaColumns.MIME_TYPE, m.mimeType);
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, dir + "/RecoverX");
        cv.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = cr.insert(collection, cv);
        if (uri == null) throw new IOException("Could not create file");
        try (InputStream in = new FileInputStream(new File(m.localPath)); OutputStream out = cr.openOutputStream(uri)) {
            if (out == null) throw new IOException("Could not write file");
            copy(in, out);
        } catch (IOException e) {
            cr.delete(uri, null, null);
            throw e;
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        cr.update(uri, done, null, null);
        return dir + "/RecoverX/" + m.fileName;
    }

    /** Copies files into a folder the user picked. Returns how many were saved. */
    public static int exportToTree(Context context, Uri tree, List<PreservedMedia> items) {
        ContentResolver cr = context.getContentResolver();
        Uri parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree));
        int saved = 0;
        for (PreservedMedia m : items) {
            File src = new File(m.localPath);
            if (!src.exists()) continue;
            String mime = m.mimeType != null ? m.mimeType : "application/octet-stream";
            try {
                Uri doc = DocumentsContract.createDocument(cr, parent, mime, m.fileName);
                if (doc == null) continue;
                try (InputStream in = new FileInputStream(src); OutputStream out = cr.openOutputStream(doc)) {
                    if (out == null) continue;
                    copy(in, out);
                    saved++;
                }
            } catch (Exception ignored) {
            }
        }
        return saved;
    }

    private static void copy(InputStream in, OutputStream out) throws IOException {
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
    }
}
