package com.recoverx.app.ui;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;

import com.google.android.material.chip.ChipGroup;
import com.recoverx.app.R;
import com.recoverx.app.data.DatabaseHelper;

/** All saved messages, newest first, with quick search and a type filter. */
public class MessagesFragment extends BaseListFragment {

    private String query = "";
    private String type = null;

    @Override
    protected int layoutRes() {
        return R.layout.fragment_messages;
    }

    @Override
    protected int titleRes() {
        return R.string.messages_title;
    }

    @Override
    protected int emptyRes() {
        return R.string.no_messages_yet;
    }

    @Override
    protected void onViewReady() {
        EditText search = root.findViewById(R.id.search_box);
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                query = s.toString();
                reload();
            }
        });
        ChipGroup chips = root.findViewById(R.id.type_chips);
        UiHelper.bindTypeChips(requireContext(), chips, selected -> {
            type = selected;
            reload();
        });
    }

    @Override
    protected DatabaseHelper.Filter buildFilter() {
        DatabaseHelper.Filter f = new DatabaseHelper.Filter();
        f.query = query;
        f.type = type;
        f.limit = 1000;
        return f;
    }

    @Override
    protected boolean hasActiveFilter() {
        return !query.trim().isEmpty() || type != null;
    }
}
