package com.recoverx.app.ui;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.recoverx.app.R;
import com.recoverx.app.data.BackupManager;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.util.AppUtils;

import org.json.JSONException;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * JSON export and import through the Android file picker (no storage permission needed),
 * plus local backups in RecoverX's own folder that survive "Clear all records".
 */
public class BackupActivity extends AppCompatActivity {

    private LinearLayout container;
    private TextView emptyText;

    private final ActivityResultLauncher<String> createFile = registerForActivityResult(
            new ActivityResultContracts.CreateDocument("application/json"), this::onExportTarget);

    private final ActivityResultLauncher<String[]> openFile = registerForActivityResult(
            new ActivityResultContracts.OpenDocument(), this::onImportSource);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_backup);
        UiHelper.setupToolbar(this, R.string.backup_title);
        container = findViewById(R.id.backup_container);
        emptyText = findViewById(R.id.backup_empty);

        findViewById(R.id.btn_export).setOnClickListener(v -> {
            String name = "RecoverX-" + new SimpleDateFormat("yyyy-MM-dd", Locale.ENGLISH).format(new Date()) + ".json";
            createFile.launch(name);
        });
        findViewById(R.id.btn_import).setOnClickListener(v -> openFile.launch(new String[]{"application/json", "text/plain", "*/*"}));
        findViewById(R.id.btn_local).setOnClickListener(v -> confirmLocalBackup());
        refreshLocalList();
    }

    private void onExportTarget(Uri uri) {
        if (uri == null) return;
        final Context app = getApplicationContext();
        AppUtils.background(() -> BackupManager.exportTo(app, uri),
                count -> Toast.makeText(app, getString(R.string.export_done, count), Toast.LENGTH_LONG).show(),
                e -> Toast.makeText(app, getString(R.string.backup_failed, e.getMessage()), Toast.LENGTH_LONG).show());
    }

    private void onImportSource(Uri uri) {
        if (uri == null) return;
        final Context app = getApplicationContext();
        AppUtils.background(() -> BackupManager.importFrom(app, uri),
                r -> Toast.makeText(app, getString(R.string.import_done, r.added, r.skipped), Toast.LENGTH_LONG).show(),
                this::showImportError);
    }

    private void showImportError(Exception e) {
        String message = e instanceof JSONException ? getString(R.string.import_failed) : getString(R.string.backup_failed, e.getMessage());
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void confirmLocalBackup() {
        final Context app = getApplicationContext();
        AppUtils.background(() -> DatabaseHelper.get(app).stats(AppUtils.startOfToday()).total, total ->
                new MaterialAlertDialogBuilder(this)
                        .setTitle(R.string.confirm_backup_title)
                        .setMessage(getString(R.string.confirm_backup_body, total.intValue()))
                        .setPositiveButton(R.string.local_backup, (d, w) -> AppUtils.background(() -> BackupManager.createLocalBackup(app),
                                file -> {
                                    Toast.makeText(app, getString(R.string.export_done, total.intValue()), Toast.LENGTH_LONG).show();
                                    refreshLocalList();
                                },
                                e -> Toast.makeText(app, getString(R.string.backup_failed, e.getMessage()), Toast.LENGTH_LONG).show()))
                        .setNegativeButton(R.string.cancel, null)
                        .show(), null);
    }

    private void refreshLocalList() {
        final Context app = getApplicationContext();
        AppUtils.background(() -> BackupManager.listLocalBackups(app), (List<File> files) -> {
            if (isFinishing()) return;
            container.removeAllViews();
            emptyText.setVisibility(files.isEmpty() ? View.VISIBLE : View.GONE);
            LayoutInflater inflater = LayoutInflater.from(this);
            for (File file : files) {
                View row = inflater.inflate(R.layout.item_backup, container, false);
                ((TextView) row.findViewById(R.id.backup_name)).setText(file.getName());
                ((TextView) row.findViewById(R.id.backup_info)).setText(
                        AppUtils.formatDateTime(file.lastModified()) + " · " + AppUtils.formatBytes(file.length()));
                row.findViewById(R.id.btn_restore).setOnClickListener(v -> confirmRestore(file));
                row.findViewById(R.id.btn_delete_backup).setOnClickListener(v -> confirmDeleteBackup(file));
                container.addView(row);
            }
        }, null);
    }

    private void confirmRestore(File file) {
        final Context app = getApplicationContext();
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.restore_confirm_title)
                .setMessage(R.string.restore_confirm_body)
                .setPositiveButton(R.string.restore, (d, w) -> AppUtils.background(() -> BackupManager.restoreLocal(app, file),
                        r -> Toast.makeText(app, getString(R.string.import_done, r.added, r.skipped), Toast.LENGTH_LONG).show(),
                        this::showImportError))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    /** Backups are protected: the user must type DELETE before a backup file is removed. */
    private void confirmDeleteBackup(File file) {
        EditText input = new EditText(this);
        input.setHint(R.string.delete_backup_hint);
        input.setSingleLine(true);
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        LinearLayout wrapper = new LinearLayout(this);
        wrapper.setPadding(pad, pad / 2, pad, 0);
        wrapper.addView(input, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.delete_backup_title)
                .setMessage(R.string.delete_backup_body)
                .setView(wrapper)
                .setPositiveButton(R.string.delete, (d, w) -> {
                    if (getString(R.string.delete_word).equals(input.getText().toString().trim())) {
                        //noinspection ResultOfMethodCallIgnored
                        file.delete();
                        refreshLocalList();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
