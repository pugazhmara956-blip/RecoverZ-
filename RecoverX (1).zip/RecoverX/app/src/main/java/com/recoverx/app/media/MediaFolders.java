package com.recoverx.app.media;

import android.net.Uri;
import android.provider.DocumentsContract;

import com.recoverx.app.data.MessageType;
import com.recoverx.app.data.Prefs;

/** Known public media folders of supported apps. Only folders the user picks with the system picker are ever read. */
public final class MediaFolders {
    private MediaFolders() {
    }

    public static final String AUTHORITY = "com.android.externalstorage.documents";

    /** Subfolder name (without app prefix) and the media type it holds. */
    public static final String[][] SUBFOLDERS = {
            {"Images", MessageType.IMAGE},
            {"Video", MessageType.VIDEO},
            {"Voice Notes", MessageType.VOICE},
            {"Audio", MessageType.AUDIO},
            {"Documents", MessageType.DOCUMENT},
            {"Animated Gifs", MessageType.GIF},
    };

    /** Folders inside media subfolders that are never read. */
    public static boolean isSkippedChild(String name) {
        if (name == null) return true;
        return name.equalsIgnoreCase("Sent") || name.equalsIgnoreCase("Private") || name.startsWith(".");
    }

    public static String prefix(String packageName) {
        return Prefs.PKG_WHATSAPP_BUSINESS.equals(packageName) ? "WhatsApp Business " : "WhatsApp ";
    }

    /** Suggested starting location for the folder picker. */
    public static Uri initialUri(String packageName) {
        String path = Prefs.PKG_WHATSAPP_BUSINESS.equals(packageName)
                ? "primary:Android/media/com.whatsapp.w4b/WhatsApp Business/Media"
                : "primary:Android/media/com.whatsapp/WhatsApp/Media";
        return DocumentsContract.buildDocumentUri(AUTHORITY, path);
    }

    public static String displayPath(String packageName) {
        return Prefs.PKG_WHATSAPP_BUSINESS.equals(packageName)
                ? "Android/media/com.whatsapp.w4b/WhatsApp Business/Media"
                : "Android/media/com.whatsapp/WhatsApp/Media";
    }

    /** Media type of a subfolder, or null if it is not a media subfolder. */
    public static String typeForFolder(String packageName, String folderName) {
        if (folderName == null) return null;
        String p = prefix(packageName);
        for (String[] s : SUBFOLDERS) {
            if (folderName.equalsIgnoreCase(p + s[0]) || folderName.equalsIgnoreCase(s[0])) return s[1];
        }
        return null;
    }

    /** Best guess from a MIME type when the folder does not tell. */
    public static String typeForMime(String mime) {
        if (mime == null) return MessageType.DOCUMENT;
        if (mime.equals("image/gif")) return MessageType.GIF;
        if (mime.startsWith("image/")) return MessageType.IMAGE;
        if (mime.startsWith("video/")) return MessageType.VIDEO;
        if (mime.startsWith("audio/")) return MessageType.AUDIO;
        return MessageType.DOCUMENT;
    }
}
