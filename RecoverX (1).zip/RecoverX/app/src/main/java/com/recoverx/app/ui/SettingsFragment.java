package com.recoverx.app.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.recoverx.app.R;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.data.Prefs;
import com.recoverx.app.media.MediaScheduler;
import com.recoverx.app.util.AppUtils;

/** Capture choices, access and background settings, and data tools. */
public class SettingsFragment extends Fragment {

    private View root;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        root = inflater.inflate(R.layout.fragment_settings, container, false);
        Context ctx = requireContext();

        bindSwitch(R.id.row_whatsapp, R.id.sw_whatsapp, Prefs.isPackageEnabled(ctx, Prefs.PKG_WHATSAPP),
                on -> Prefs.setPackageEnabled(ctx, Prefs.PKG_WHATSAPP, on));
        bindSwitch(R.id.row_business, R.id.sw_business, Prefs.isPackageEnabled(ctx, Prefs.PKG_WHATSAPP_BUSINESS),
                on -> Prefs.setPackageEnabled(ctx, Prefs.PKG_WHATSAPP_BUSINESS, on));
        bindSwitch(R.id.row_instagram, R.id.sw_instagram, Prefs.isPackageEnabled(ctx, Prefs.PKG_INSTAGRAM),
                on -> Prefs.setPackageEnabled(ctx, Prefs.PKG_INSTAGRAM, on));
        bindSwitch(R.id.row_autodetect, R.id.sw_autodetect, Prefs.isAutoDetectDeleted(ctx),
                on -> Prefs.setAutoDetectDeleted(ctx, on));
        bindSwitch(R.id.row_media, R.id.sw_media, Prefs.isCaptureMedia(ctx),
                on -> {
                    Prefs.setCaptureMedia(ctx, on);
                    MediaScheduler.sync(ctx);
                });

        root.findViewById(R.id.link_access).setOnClickListener(v -> AppUtils.openNotificationAccess(requireActivity()));
        root.findViewById(R.id.link_battery).setOnClickListener(v -> AppUtils.openBatterySettings(requireActivity()));
        root.findViewById(R.id.link_autostart).setOnClickListener(v -> AppUtils.openXiaomiAutostart(requireActivity()));
        root.findViewById(R.id.link_backup).setOnClickListener(v -> startActivity(new Intent(ctx, BackupActivity.class)));
        root.findViewById(R.id.link_media).setOnClickListener(v -> startActivity(new Intent(ctx, MediaSetupActivity.class)));
        root.findViewById(R.id.link_search).setOnClickListener(v -> startActivity(new Intent(ctx, SearchActivity.class)));
        root.findViewById(R.id.link_about).setOnClickListener(v -> startActivity(new Intent(ctx, AboutActivity.class)));
        root.findViewById(R.id.link_clear).setOnClickListener(v -> confirmClear());
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        boolean granted = AppUtils.hasNotificationAccess(requireContext());
        TextView desc = root.findViewById(R.id.link_desc_access);
        desc.setText(granted ? R.string.status_access_on : R.string.status_access_off);
        desc.setTextColor(ContextCompat.getColor(requireContext(), granted ? R.color.neon : R.color.warning));
    }

    private interface OnToggle {
        void onToggle(boolean on);
    }

    private void bindSwitch(int rowId, int switchId, boolean checked, OnToggle onToggle) {
        MaterialSwitch sw = root.findViewById(switchId);
        sw.setChecked(checked);
        sw.setOnCheckedChangeListener((b, isChecked) -> onToggle.onToggle(isChecked));
        root.findViewById(rowId).setOnClickListener(v -> sw.toggle());
    }

    private void confirmClear() {
        new MaterialAlertDialogBuilder(requireContext())
                .setTitle(R.string.clear_all_title)
                .setMessage(R.string.clear_all_body)
                .setPositiveButton(R.string.delete, (d, w) -> {
                    final Context app = requireContext().getApplicationContext();
                    AppUtils.background(() -> {
                        DatabaseHelper.get(app).clearAll();
                        return true;
                    }, r -> Toast.makeText(app, R.string.cleared, Toast.LENGTH_SHORT).show(), null);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
