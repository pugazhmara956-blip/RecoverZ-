package com.recoverx.app;

import android.app.Application;

import androidx.appcompat.app.AppCompatDelegate;

import com.recoverx.app.media.MediaScheduler;

/** RecoverX always uses its black theme, independent of the system setting. */
public class RecoverXApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        try {
            MediaScheduler.sync(this);
        } catch (Exception ignored) {
            // WorkManager problems must never stop the app from opening.
        }
    }
}
