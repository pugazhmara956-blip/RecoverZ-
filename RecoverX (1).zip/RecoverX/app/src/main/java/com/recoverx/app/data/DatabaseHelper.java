package com.recoverx.app.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** SQLite storage for captured notifications. All queries use bound parameters. */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DatabaseHelper";
    public static final String DB_NAME = "recoverx.db";
    private static final int DB_VERSION = 2;

    public static final String TABLE = "captured_notifications";
    public static final String COL_ID = "id";
    public static final String COL_PACKAGE = "package_name";
    public static final String COL_CONVERSATION = "conversation";
    public static final String COL_SENDER = "sender_name";
    public static final String COL_TEXT = "message_text";
    public static final String COL_TIMESTAMP = "timestamp";
    public static final String COL_TYPE = "message_type";
    public static final String COL_MARKED = "manually_marked_deleted";
    public static final String COL_POSSIBLY = "possibly_deleted";
    public static final String COL_MEDIA = "media_path";
    public static final String COL_DEDUPE = "dedupe_key";
    public static final String COL_CREATED = "created_at";

    // Version 2: preserved media copied from user-authorized folders
    public static final String MEDIA_TABLE = "preserved_media";
    public static final String SEEN_TABLE = "seen_sources";

    /** Notified on the main thread whenever records change, so open screens can refresh. */
    public interface ChangeListener {
        void onDataChanged();
    }

    private static volatile DatabaseHelper instance;
    private static final List<ChangeListener> listeners = new CopyOnWriteArrayList<>();
    private static final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final Context appContext;

    public static DatabaseHelper get(Context context) {
        if (instance == null) {
            synchronized (DatabaseHelper.class) {
                if (instance == null) instance = new DatabaseHelper(context.getApplicationContext());
            }
        }
        return instance;
    }

    private DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        appContext = context;
    }

    public static void addListener(ChangeListener l) {
        listeners.add(l);
    }

    public static void removeListener(ChangeListener l) {
        listeners.remove(l);
    }

    private static void notifyChanged() {
        mainHandler.post(() -> {
            for (ChangeListener l : listeners) l.onDataChanged();
        });
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE + " ("
                + COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_PACKAGE + " TEXT NOT NULL, "
                + COL_CONVERSATION + " TEXT, "
                + COL_SENDER + " TEXT, "
                + COL_TEXT + " TEXT, "
                + COL_TIMESTAMP + " INTEGER NOT NULL, "
                + COL_TYPE + " TEXT NOT NULL, "
                + COL_MARKED + " INTEGER NOT NULL DEFAULT 0, "
                + COL_POSSIBLY + " INTEGER NOT NULL DEFAULT 0, "
                + COL_MEDIA + " TEXT, "
                + COL_DEDUPE + " TEXT NOT NULL UNIQUE, "
                + COL_CREATED + " INTEGER NOT NULL)");
        db.execSQL("CREATE INDEX idx_timestamp ON " + TABLE + " (" + COL_TIMESTAMP + ")");
        db.execSQL("CREATE INDEX idx_sender ON " + TABLE + " (" + COL_SENDER + ")");
        db.execSQL("CREATE INDEX idx_conversation ON " + TABLE + " (" + COL_PACKAGE + ", " + COL_CONVERSATION + ")");
        createMediaTables(db);
    }

    private static void createMediaTables(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + MEDIA_TABLE + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "package_name TEXT NOT NULL, "
                + "source_key TEXT NOT NULL UNIQUE, "
                + "file_name TEXT NOT NULL, "
                + "mime_type TEXT, "
                + "media_type TEXT NOT NULL, "
                + "size_bytes INTEGER NOT NULL, "
                + "sha256 TEXT NOT NULL UNIQUE, "
                + "local_path TEXT NOT NULL, "
                + "source_modified INTEGER NOT NULL, "
                + "captured_at INTEGER NOT NULL, "
                + "capture_method TEXT NOT NULL, "
                + "source_missing INTEGER NOT NULL DEFAULT 0, "
                + "source_missing_at INTEGER NOT NULL DEFAULT 0, "
                + "manually_marked_deleted INTEGER NOT NULL DEFAULT 0, "
                + "integrity_status TEXT NOT NULL DEFAULT 'UNCHECKED', "
                + "verified_at INTEGER NOT NULL DEFAULT 0, "
                + "linked_message_id INTEGER NOT NULL DEFAULT 0, "
                + "sender_guess TEXT, "
                + "conversation_guess TEXT)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_media_type ON " + MEDIA_TABLE + " (media_type, source_modified)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_media_package ON " + MEDIA_TABLE + " (package_name)");
        // Files already looked at (for example exact duplicates), so they are not hashed again on every scan.
        db.execSQL("CREATE TABLE IF NOT EXISTS " + SEEN_TABLE + " (source_key TEXT PRIMARY KEY, seen_at INTEGER NOT NULL)");
    }

    /**
     * Step-by-step migrations. Each future version adds a case; data is never dropped.
     * Example for version 2: case 1: db.execSQL("ALTER TABLE ... ADD COLUMN ...");
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.i(TAG, "Upgrading database from " + oldVersion + " to " + newVersion);
        // Each step runs in order; existing records are always kept.
        if (oldVersion < 2) {
            createMediaTables(db);
        }
    }

    // ------------------------------------------------------------------ writes

    /** Inserts a message unless an identical one is already saved. Returns the new id, or -1. */
    public long insertIfNew(CapturedMessage m) {
        ContentValues cv = toValues(m);
        long id;
        try {
            id = getWritableDatabase().insertWithOnConflict(TABLE, null, cv, SQLiteDatabase.CONFLICT_IGNORE);
        } catch (Exception e) {
            Log.w(TAG, "Insert failed", e);
            return -1;
        }
        if (id != -1) notifyChanged();
        return id;
    }

    /**
     * Flags the latest earlier message from this sender in this chat as possibly deleted.
     * Called when WhatsApp shows "This message was deleted".
     */
    public void flagLatestAsPossiblyDeleted(String packageName, String conversation, String sender, long beforeTime) {
        try {
            SQLiteDatabase db = getWritableDatabase();
            String where = COL_PACKAGE + " = ? AND " + COL_CONVERSATION + " = ? AND " + COL_SENDER + " = ? AND "
                    + COL_TIMESTAMP + " <= ? AND " + COL_POSSIBLY + " = 0";
            String[] args = {packageName, nullToEmpty(conversation), nullToEmpty(sender), String.valueOf(beforeTime)};
            long targetId = -1;
            try (Cursor c = db.query(TABLE, new String[]{COL_ID}, where, args, null, null, COL_TIMESTAMP + " DESC", "1")) {
                if (c.moveToFirst()) targetId = c.getLong(0);
            }
            if (targetId == -1) return;
            ContentValues cv = new ContentValues();
            cv.put(COL_POSSIBLY, 1);
            db.update(TABLE, cv, COL_ID + " = ?", new String[]{String.valueOf(targetId)});
            notifyChanged();
        } catch (Exception e) {
            Log.w(TAG, "Could not flag deleted message", e);
        }
    }

    public void setManuallyDeleted(long id, boolean deleted) {
        ContentValues cv = new ContentValues();
        cv.put(COL_MARKED, deleted ? 1 : 0);
        if (!deleted) cv.put(COL_POSSIBLY, 0);
        getWritableDatabase().update(TABLE, cv, COL_ID + " = ?", new String[]{String.valueOf(id)});
        notifyChanged();
    }

    public void delete(CapturedMessage m) {
        getWritableDatabase().delete(TABLE, COL_ID + " = ?", new String[]{String.valueOf(m.id)});
        deleteMediaFile(m.mediaPath);
        notifyChanged();
    }

    public void clearAll() {
        getWritableDatabase().delete(TABLE, null, null);
        File dir = new File(appContext.getFilesDir(), "media");
        File[] files = dir.listFiles();
        if (files != null) for (File f : files) //noinspection ResultOfMethodCallIgnored
            f.delete();
        notifyChanged();
    }

    // ------------------------------------------------------------------ reads

    /** Search and filter options. Null values mean "no filter". */
    public static class Filter {
        public String query;
        public String type;
        /** Limit to one app, or null for all apps. */
        public String packageName;
        public Long fromMillis;
        public Long toMillis;
        public boolean deletedOnly;
        public boolean mediaOnly;
        public boolean newestFirst = true;
        public int limit = 0;
    }

    public List<CapturedMessage> query(Filter f) {
        StringBuilder where = new StringBuilder("1 = 1");
        List<String> args = new ArrayList<>();
        if (f.query != null && !f.query.trim().isEmpty()) {
            String like = "%" + f.query.trim() + "%";
            where.append(" AND (").append(COL_SENDER).append(" LIKE ? OR ")
                    .append(COL_CONVERSATION).append(" LIKE ? OR ")
                    .append(COL_TEXT).append(" LIKE ?)");
            args.add(like);
            args.add(like);
            args.add(like);
        }
        if (f.type != null) {
            where.append(" AND ").append(COL_TYPE).append(" = ?");
            args.add(f.type);
        }
        if (f.packageName != null) {
            where.append(" AND ").append(COL_PACKAGE).append(" = ?");
            args.add(f.packageName);
        }
        if (f.fromMillis != null) {
            where.append(" AND ").append(COL_TIMESTAMP).append(" >= ?");
            args.add(String.valueOf(f.fromMillis));
        }
        if (f.toMillis != null) {
            where.append(" AND ").append(COL_TIMESTAMP).append(" < ?");
            args.add(String.valueOf(f.toMillis));
        }
        if (f.deletedOnly) {
            where.append(" AND (").append(COL_MARKED).append(" = 1 OR ").append(COL_POSSIBLY).append(" = 1)");
        }
        if (f.mediaOnly) {
            where.append(" AND ").append(COL_TYPE).append(" IN (?, ?, ?, ?)");
            args.add(MessageType.IMAGE);
            args.add(MessageType.VIDEO);
            args.add(MessageType.AUDIO);
            args.add(MessageType.DOCUMENT);
        }
        String order = COL_TIMESTAMP + (f.newestFirst ? " DESC" : " ASC") + ", " + COL_ID + (f.newestFirst ? " DESC" : " ASC");
        String limit = f.limit > 0 ? String.valueOf(f.limit) : null;
        List<CapturedMessage> list = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query(TABLE, null, where.toString(), args.toArray(new String[0]), null, null, order, limit)) {
            while (c.moveToNext()) list.add(fromCursor(c));
        } catch (Exception e) {
            Log.w(TAG, "Query failed", e);
        }
        return list;
    }

    public List<CapturedMessage> all() {
        Filter f = new Filter();
        f.newestFirst = false;
        return query(f);
    }

    public static class Stats {
        public long total;
        public long text;
        public long today;
        public long deleted;
        public long storageBytes;
    }

    public Stats stats(long startOfToday) {
        Stats s = new Stats();
        SQLiteDatabase db = getReadableDatabase();
        s.total = count(db, null, null);
        s.text = count(db, COL_TYPE + " = ?", new String[]{MessageType.TEXT});
        s.today = count(db, COL_TIMESTAMP + " >= ?", new String[]{String.valueOf(startOfToday)});
        s.deleted = count(db, COL_MARKED + " = 1 OR " + COL_POSSIBLY + " = 1", null);
        s.storageBytes = sizeOf(appContext.getDatabasePath(DB_NAME)) + sizeOf(new File(appContext.getFilesDir(), "media"))
                + sizeOf(new File(appContext.getFilesDir(), "preserved"));
        return s;
    }

    private long count(SQLiteDatabase db, String where, String[] args) {
        try (Cursor c = db.query(TABLE, new String[]{"COUNT(*)"}, where, args, null, null, null)) {
            return c.moveToFirst() ? c.getLong(0) : 0;
        } catch (Exception e) {
            return 0;
        }
    }

    // ------------------------------------------------------------------ helpers

    private static ContentValues toValues(CapturedMessage m) {
        ContentValues cv = new ContentValues();
        cv.put(COL_PACKAGE, m.packageName);
        cv.put(COL_CONVERSATION, nullToEmpty(m.conversation));
        cv.put(COL_SENDER, nullToEmpty(m.senderName));
        cv.put(COL_TEXT, m.messageText);
        cv.put(COL_TIMESTAMP, m.timestamp);
        cv.put(COL_TYPE, m.messageType);
        cv.put(COL_MARKED, m.manuallyMarkedDeleted ? 1 : 0);
        cv.put(COL_POSSIBLY, m.possiblyDeleted ? 1 : 0);
        cv.put(COL_MEDIA, m.mediaPath);
        cv.put(COL_DEDUPE, m.dedupeKey);
        cv.put(COL_CREATED, m.createdAt);
        return cv;
    }

    private static CapturedMessage fromCursor(Cursor c) {
        CapturedMessage m = new CapturedMessage();
        m.id = c.getLong(c.getColumnIndexOrThrow(COL_ID));
        m.packageName = c.getString(c.getColumnIndexOrThrow(COL_PACKAGE));
        m.conversation = c.getString(c.getColumnIndexOrThrow(COL_CONVERSATION));
        m.senderName = c.getString(c.getColumnIndexOrThrow(COL_SENDER));
        m.messageText = c.getString(c.getColumnIndexOrThrow(COL_TEXT));
        m.timestamp = c.getLong(c.getColumnIndexOrThrow(COL_TIMESTAMP));
        m.messageType = c.getString(c.getColumnIndexOrThrow(COL_TYPE));
        m.manuallyMarkedDeleted = c.getInt(c.getColumnIndexOrThrow(COL_MARKED)) == 1;
        m.possiblyDeleted = c.getInt(c.getColumnIndexOrThrow(COL_POSSIBLY)) == 1;
        m.mediaPath = c.getString(c.getColumnIndexOrThrow(COL_MEDIA));
        m.dedupeKey = c.getString(c.getColumnIndexOrThrow(COL_DEDUPE));
        m.createdAt = c.getLong(c.getColumnIndexOrThrow(COL_CREATED));
        return m;
    }

    // ------------------------------------------------------------------ preserved media

    public boolean hasMediaHash(String sha256) {
        try (Cursor c = getReadableDatabase().query(MEDIA_TABLE, new String[]{"id"}, "sha256 = ?", new String[]{sha256}, null, null, null, "1")) {
            return c.moveToFirst();
        }
    }

    /** Source keys that are already handled (copied or skipped as duplicates). */
    public java.util.Set<String> knownSourceKeys(String packageName) {
        java.util.Set<String> keys = new java.util.HashSet<>();
        SQLiteDatabase db = getReadableDatabase();
        try (Cursor c = db.query(MEDIA_TABLE, new String[]{"source_key"}, "package_name = ?", new String[]{packageName}, null, null, null)) {
            while (c.moveToNext()) keys.add(c.getString(0));
        }
        try (Cursor c = db.query(SEEN_TABLE, new String[]{"source_key"}, "source_key LIKE ?", new String[]{packageName + "|%"}, null, null, null)) {
            while (c.moveToNext()) keys.add(c.getString(0));
        }
        return keys;
    }

    public void markSeen(String sourceKey) {
        ContentValues cv = new ContentValues();
        cv.put("source_key", sourceKey);
        cv.put("seen_at", System.currentTimeMillis());
        getWritableDatabase().insertWithOnConflict(SEEN_TABLE, null, cv, SQLiteDatabase.CONFLICT_IGNORE);
    }

    public long insertMedia(PreservedMedia m) {
        ContentValues cv = new ContentValues();
        cv.put("package_name", m.packageName);
        cv.put("source_key", m.sourceKey);
        cv.put("file_name", m.fileName);
        cv.put("mime_type", m.mimeType);
        cv.put("media_type", m.mediaType);
        cv.put("size_bytes", m.sizeBytes);
        cv.put("sha256", m.sha256);
        cv.put("local_path", m.localPath);
        cv.put("source_modified", m.sourceModified);
        cv.put("captured_at", m.capturedAt);
        cv.put("capture_method", m.captureMethod);
        cv.put("integrity_status", m.integrityStatus);
        cv.put("linked_message_id", m.linkedMessageId);
        cv.put("sender_guess", m.senderGuess);
        cv.put("conversation_guess", m.conversationGuess);
        long id = getWritableDatabase().insertWithOnConflict(MEDIA_TABLE, null, cv, SQLiteDatabase.CONFLICT_IGNORE);
        if (id != -1) notifyChanged();
        return id;
    }

    /** Marks copies whose original is no longer in the authorized folder. */
    public int markSourcesMissing(String packageName, java.util.Set<String> presentKeys, java.util.Set<String> scannedTypes) {
        SQLiteDatabase db = getWritableDatabase();
        List<Long> missing = new ArrayList<>();
        try (Cursor c = db.query(MEDIA_TABLE, new String[]{"id", "source_key", "media_type"},
                "package_name = ? AND source_missing = 0 AND capture_method = ?",
                new String[]{packageName, PreservedMedia.METHOD_FOLDER}, null, null, null)) {
            while (c.moveToNext()) {
                if (!scannedTypes.contains(c.getString(2))) continue;
                if (!presentKeys.contains(c.getString(1))) missing.add(c.getLong(0));
            }
        }
        long now = System.currentTimeMillis();
        for (Long id : missing) {
            ContentValues cv = new ContentValues();
            cv.put("source_missing", 1);
            cv.put("source_missing_at", now);
            db.update(MEDIA_TABLE, cv, "id = ?", new String[]{String.valueOf(id)});
        }
        if (!missing.isEmpty()) notifyChanged();
        return missing.size();
    }

    public void setMediaManuallyDeleted(long id, boolean deleted) {
        ContentValues cv = new ContentValues();
        cv.put("manually_marked_deleted", deleted ? 1 : 0);
        getWritableDatabase().update(MEDIA_TABLE, cv, "id = ?", new String[]{String.valueOf(id)});
        notifyChanged();
    }

    public void setIntegrity(long id, String status) {
        ContentValues cv = new ContentValues();
        cv.put("integrity_status", status);
        cv.put("verified_at", System.currentTimeMillis());
        getWritableDatabase().update(MEDIA_TABLE, cv, "id = ?", new String[]{String.valueOf(id)});
        notifyChanged();
    }

    public void deleteMedia(PreservedMedia m) {
        getWritableDatabase().delete(MEDIA_TABLE, "id = ?", new String[]{String.valueOf(m.id)});
        // Remember the source so the same file is not copied again on the next scan.
        markSeen(m.sourceKey);
        deleteMediaFile(m.localPath);
        notifyChanged();
    }

    public int mediaTotal() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + MEDIA_TABLE, null)) {
            return c.moveToFirst() ? c.getInt(0) : 0;
        }
    }

    /**
     * Deletes every preserved copy. The source keys are remembered (no file content is kept)
     * so the same files are not copied again on the next scan.
     */
    public void clearAllMedia(Context context) {
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT OR IGNORE INTO " + SEEN_TABLE + " (source_key, seen_at) SELECT source_key, ? FROM " + MEDIA_TABLE,
                new Object[]{System.currentTimeMillis()});
        db.delete(MEDIA_TABLE, null, null);
        File dir = new File(context.getFilesDir(), "preserved");
        File[] files = dir.listFiles();
        if (files != null) for (File f : files) //noinspection ResultOfMethodCallIgnored
            f.delete();
        notifyChanged();
    }

    public long preservedBytes() {
        try (Cursor c = getReadableDatabase().rawQuery("SELECT COALESCE(SUM(size_bytes), 0) FROM " + MEDIA_TABLE, null)) {
            return c.moveToFirst() ? c.getLong(0) : 0;
        }
    }

    /** Copies whose original still exists and that are older than the cutoff (removed files are never auto-deleted). */
    public List<PreservedMedia> expiredMedia(long cutoff) {
        String where = "source_missing = 0 AND manually_marked_deleted = 0 AND captured_at < ?";
        return queryMediaRaw(where, new String[]{String.valueOf(cutoff)}, "captured_at ASC", null);
    }

    /** Media filter. Null values mean "no filter". */
    public static class MediaFilter {
        /** One or more media types, or null for all. */
        public String[] mediaTypes;
        public String packageName;
        public String senderQuery;
        public Long fromMillis;
        public Long toMillis;
        public boolean deletedOnly;
        public boolean newestFirst = true;
    }

    public List<PreservedMedia> queryMedia(MediaFilter f) {
        StringBuilder where = new StringBuilder("1 = 1");
        List<String> args = new ArrayList<>();
        if (f.mediaTypes != null && f.mediaTypes.length > 0) {
            where.append(" AND media_type IN (");
            for (int i = 0; i < f.mediaTypes.length; i++) {
                where.append(i == 0 ? "?" : ", ?");
                args.add(f.mediaTypes[i]);
            }
            where.append(")");
        }
        if (f.packageName != null) {
            where.append(" AND package_name = ?");
            args.add(f.packageName);
        }
        if (f.senderQuery != null && !f.senderQuery.trim().isEmpty()) {
            String like = "%" + f.senderQuery.trim() + "%";
            where.append(" AND (sender_guess LIKE ? OR conversation_guess LIKE ? OR file_name LIKE ?)");
            args.add(like);
            args.add(like);
            args.add(like);
        }
        if (f.fromMillis != null) {
            where.append(" AND source_modified >= ?");
            args.add(String.valueOf(f.fromMillis));
        }
        if (f.toMillis != null) {
            where.append(" AND source_modified < ?");
            args.add(String.valueOf(f.toMillis));
        }
        if (f.deletedOnly) where.append(" AND (source_missing = 1 OR manually_marked_deleted = 1)");
        String order = "source_modified " + (f.newestFirst ? "DESC" : "ASC");
        return queryMediaRaw(where.toString(), args.toArray(new String[0]), order, null);
    }

    public PreservedMedia getMedia(long id) {
        List<PreservedMedia> list = queryMediaRaw("id = ?", new String[]{String.valueOf(id)}, null, "1");
        return list.isEmpty() ? null : list.get(0);
    }

    /** Counts for one or more media types: [deleted, total]. */
    public long[] mediaCounts(String[] mediaTypes) {
        SQLiteDatabase db = getReadableDatabase();
        long total = 0;
        long deleted = 0;
        StringBuilder in = new StringBuilder();
        for (int i = 0; i < mediaTypes.length; i++) in.append(i == 0 ? "?" : ", ?");
        try (Cursor c = db.rawQuery("SELECT COUNT(*), COALESCE(SUM(CASE WHEN source_missing = 1 OR manually_marked_deleted = 1 THEN 1 ELSE 0 END), 0) FROM "
                + MEDIA_TABLE + " WHERE media_type IN (" + in + ")", mediaTypes)) {
            if (c.moveToFirst()) {
                total = c.getLong(0);
                deleted = c.getLong(1);
            }
        }
        return new long[]{deleted, total};
    }

    public long[] textDeletedCounts() {
        SQLiteDatabase db = getReadableDatabase();
        long deleted = count(db, COL_MARKED + " = 1 OR " + COL_POSSIBLY + " = 1", null);
        long total = count(db, null, null);
        return new long[]{deleted, total};
    }

    /** The closest earlier notification of the same kind, used to guess the sender of a file. */
    public CapturedMessage findNotificationNear(String packageName, String[] types, long fileTime) {
        StringBuilder in = new StringBuilder();
        List<String> args = new ArrayList<>();
        args.add(packageName);
        for (int i = 0; i < types.length; i++) {
            in.append(i == 0 ? "?" : ", ?");
            args.add(types[i]);
        }
        args.add(String.valueOf(fileTime - 10 * 60 * 1000L));
        args.add(String.valueOf(fileTime + 2 * 60 * 1000L));
        args.add(String.valueOf(fileTime));
        String sql = "SELECT * FROM " + TABLE + " WHERE " + COL_PACKAGE + " = ? AND " + COL_TYPE + " IN (" + in + ") AND "
                + COL_TIMESTAMP + " BETWEEN ? AND ? ORDER BY ABS(" + COL_TIMESTAMP + " - ?) ASC LIMIT 1";
        try (Cursor c = getReadableDatabase().rawQuery(sql, args.toArray(new String[0]))) {
            return c.moveToFirst() ? fromCursor(c) : null;
        } catch (Exception e) {
            return null;
        }
    }

    private List<PreservedMedia> queryMediaRaw(String where, String[] args, String order, String limit) {
        List<PreservedMedia> list = new ArrayList<>();
        try (Cursor c = getReadableDatabase().query(MEDIA_TABLE, null, where, args, null, null, order, limit)) {
            while (c.moveToNext()) list.add(mediaFromCursor(c));
        } catch (Exception e) {
            Log.w(TAG, "Media query failed", e);
        }
        return list;
    }

    private static PreservedMedia mediaFromCursor(Cursor c) {
        PreservedMedia m = new PreservedMedia();
        m.id = c.getLong(c.getColumnIndexOrThrow("id"));
        m.packageName = c.getString(c.getColumnIndexOrThrow("package_name"));
        m.sourceKey = c.getString(c.getColumnIndexOrThrow("source_key"));
        m.fileName = c.getString(c.getColumnIndexOrThrow("file_name"));
        m.mimeType = c.getString(c.getColumnIndexOrThrow("mime_type"));
        m.mediaType = c.getString(c.getColumnIndexOrThrow("media_type"));
        m.sizeBytes = c.getLong(c.getColumnIndexOrThrow("size_bytes"));
        m.sha256 = c.getString(c.getColumnIndexOrThrow("sha256"));
        m.localPath = c.getString(c.getColumnIndexOrThrow("local_path"));
        m.sourceModified = c.getLong(c.getColumnIndexOrThrow("source_modified"));
        m.capturedAt = c.getLong(c.getColumnIndexOrThrow("captured_at"));
        m.captureMethod = c.getString(c.getColumnIndexOrThrow("capture_method"));
        m.sourceMissing = c.getInt(c.getColumnIndexOrThrow("source_missing")) == 1;
        m.sourceMissingAt = c.getLong(c.getColumnIndexOrThrow("source_missing_at"));
        m.manuallyMarkedDeleted = c.getInt(c.getColumnIndexOrThrow("manually_marked_deleted")) == 1;
        m.integrityStatus = c.getString(c.getColumnIndexOrThrow("integrity_status"));
        m.verifiedAt = c.getLong(c.getColumnIndexOrThrow("verified_at"));
        m.linkedMessageId = c.getLong(c.getColumnIndexOrThrow("linked_message_id"));
        m.senderGuess = c.getString(c.getColumnIndexOrThrow("sender_guess"));
        m.conversationGuess = c.getString(c.getColumnIndexOrThrow("conversation_guess"));
        return m;
    }

    static String nullToEmpty(String s) {
        return s == null ? "" : s;
    }

    private static long sizeOf(File f) {
        if (f == null || !f.exists()) return 0;
        if (f.isFile()) return f.length();
        long total = 0;
        File[] children = f.listFiles();
        if (children != null) for (File child : children) total += sizeOf(child);
        return total;
    }

    private static void deleteMediaFile(String path) {
        if (path == null) return;
        File f = new File(path);
        if (f.exists()) //noinspection ResultOfMethodCallIgnored
            f.delete();
    }
}
