package com.recoverx.app.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.recoverx.app.R;
import com.recoverx.app.data.MessageType;
import com.recoverx.app.data.PreservedMedia;
import com.recoverx.app.media.ThumbnailLoader;
import com.recoverx.app.util.AppUtils;

import java.util.ArrayList;
import java.util.List;

public class MediaAdapter extends RecyclerView.Adapter<MediaAdapter.Holder> {

    public interface OnClick {
        void onClick(PreservedMedia m);
    }

    private final List<PreservedMedia> items = new ArrayList<>();
    private final OnClick onClick;

    public MediaAdapter(OnClick onClick) {
        this.onClick = onClick;
    }

    @SuppressWarnings("NotifyDataSetChanged")
    public void submit(List<PreservedMedia> list) {
        items.clear();
        items.addAll(list);
        notifyDataSetChanged();
    }

    public List<PreservedMedia> getItems() {
        return new ArrayList<>(items);
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_media, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Holder h, int position) {
        PreservedMedia m = items.get(position);
        h.name.setText(m.fileName);
        String kind = h.itemView.getContext().getString(MessageType.label(m.mediaType));
        h.meta.setText(kind + " · " + AppUtils.formatBytes(m.sizeBytes) + " · " + AppUtils.formatDateTime(m.sourceModified)
                + " · " + AppUtils.appLabel(m.packageName));
        if (m.senderGuess != null && !m.senderGuess.isEmpty()) {
            h.sender.setVisibility(View.VISIBLE);
            h.sender.setText(h.itemView.getContext().getString(R.string.maybe_from, m.senderGuess));
        } else {
            h.sender.setVisibility(View.GONE);
        }
        MediaStatus.bindBadge(h.status, m);
        boolean thumb = ThumbnailLoader.hasThumbnail(m);
        h.thumb.setPadding(thumb ? 0 : dp(h.thumb, 18), thumb ? 0 : dp(h.thumb, 18), thumb ? 0 : dp(h.thumb, 18), thumb ? 0 : dp(h.thumb, 18));
        h.thumb.setScaleType(thumb ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER);
        ThumbnailLoader.load(h.thumb, m, MediaCategory.forType(m.mediaType).iconRes);
        h.itemView.setOnClickListener(v -> onClick.onClick(m));
    }

    private static int dp(View v, int value) {
        return Math.round(value * v.getResources().getDisplayMetrics().density);
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        final ImageView thumb;
        final TextView name;
        final TextView meta;
        final TextView sender;
        final TextView status;

        Holder(View v) {
            super(v);
            thumb = v.findViewById(R.id.media_thumb);
            name = v.findViewById(R.id.media_name);
            meta = v.findViewById(R.id.media_meta);
            sender = v.findViewById(R.id.media_sender);
            status = v.findViewById(R.id.media_status);
        }
    }
}
