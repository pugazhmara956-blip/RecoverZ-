package com.recoverx.app.util;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.widget.Toast;

import androidx.core.app.NotificationManagerCompat;

import com.recoverx.app.R;
import com.recoverx.app.service.NotificationCaptureService;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Permission helpers, background execution and English-only formatting. */
public final class AppUtils {

    private static final ExecutorService IO = Executors.newSingleThreadExecutor();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private AppUtils() {
    }

    // ------------------------------------------------------------------ threading

    public interface Callback<T> {
        void onResult(T result);
    }

    public interface Work<T> {
        T run() throws Exception;
    }

    /** Runs database or file work off the main thread and delivers the result on the main thread. */
    public static <T> void background(Work<T> work, Callback<T> onDone, Callback<Exception> onError) {
        IO.execute(() -> {
            try {
                T result = work.run();
                if (onDone != null) MAIN.post(() -> onDone.onResult(result));
            } catch (Exception e) {
                if (onError != null) MAIN.post(() -> onError.onResult(e));
            }
        });
    }

    // ------------------------------------------------------------------ notification access

    public static boolean hasNotificationAccess(Context context) {
        return NotificationManagerCompat.getEnabledListenerPackages(context).contains(context.getPackageName());
    }

    public static void openNotificationAccess(Activity activity) {
        Intent intent;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS)
                    .putExtra(Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
                            new ComponentName(activity, NotificationCaptureService.class).flattenToString());
        } else {
            intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
        }
        if (!tryStart(activity, intent)) {
            if (!tryStart(activity, new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))) {
                Toast.makeText(activity, R.string.open_failed, Toast.LENGTH_SHORT).show();
            }
        }
    }

    /** Asks Android to reconnect the listener (useful after Xiaomi stopped the app). */
    public static void requestRebind(Context context) {
        if (!hasNotificationAccess(context)) return;
        try {
            NotificationListenerService.requestRebind(new ComponentName(context, NotificationCaptureService.class));
        } catch (Exception ignored) {
            // Not critical: Android rebinds the listener on its own as well.
        }
    }

    public static void openAppInfo(Activity activity) {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + activity.getPackageName()));
        if (!tryStart(activity, intent)) Toast.makeText(activity, R.string.open_failed, Toast.LENGTH_SHORT).show();
    }

    public static void openBatterySettings(Activity activity) {
        if (!tryStart(activity, new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))) openAppInfo(activity);
    }

    public static boolean isXiaomi() {
        String maker = Build.MANUFACTURER.toLowerCase(Locale.ENGLISH);
        String brand = Build.BRAND.toLowerCase(Locale.ENGLISH);
        return maker.contains("xiaomi") || brand.equals("redmi") || brand.equals("poco") || brand.equals("xiaomi");
    }

    public static void openXiaomiAutostart(Activity activity) {
        if (!isXiaomi()) {
            Toast.makeText(activity, R.string.not_xiaomi, Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent().setComponent(new ComponentName("com.miui.securitycenter",
                "com.miui.permcenter.autostart.AutoStartManagementActivity"));
        if (!tryStart(activity, intent)) openAppInfo(activity);
    }

    private static boolean tryStart(Activity activity, Intent intent) {
        try {
            activity.startActivity(intent);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    // ------------------------------------------------------------------ formatting

    public static String formatDate(long millis) {
        return new SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(new Date(millis));
    }

    public static String formatTime(long millis) {
        return new SimpleDateFormat("h:mm a", Locale.ENGLISH).format(new Date(millis));
    }

    public static String formatDateTime(long millis) {
        return new SimpleDateFormat("d MMM yyyy, h:mm a", Locale.ENGLISH).format(new Date(millis));
    }

    /** "3:45 PM" for today, "Yesterday" for yesterday, otherwise "12 Nov". */
    public static String formatShort(long millis) {
        long today = startOfToday();
        if (millis >= today) return formatTime(millis);
        if (millis >= today - 24L * 60 * 60 * 1000) return "Yesterday";
        return new SimpleDateFormat("d MMM", Locale.ENGLISH).format(new Date(millis));
    }

    public static long startOfToday() {
        Calendar c = Calendar.getInstance();
        c.set(Calendar.HOUR_OF_DAY, 0);
        c.set(Calendar.MINUTE, 0);
        c.set(Calendar.SECOND, 0);
        c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }

    public static String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        String[] units = {"KB", "MB", "GB"};
        double value = bytes / 1024.0;
        int i = 0;
        while (value >= 1024 && i < units.length - 1) {
            value /= 1024.0;
            i++;
        }
        return String.format(Locale.ENGLISH, "%.1f %s", value, units[i]);
    }

    public static String appLabel(String packageName) {
        if ("com.whatsapp.w4b".equals(packageName)) return "WhatsApp Business";
        if ("com.whatsapp".equals(packageName)) return "WhatsApp";
        if ("com.instagram.android".equals(packageName)) return "Instagram";
        return packageName;
    }
}
