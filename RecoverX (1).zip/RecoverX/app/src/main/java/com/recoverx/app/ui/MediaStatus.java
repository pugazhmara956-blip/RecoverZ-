package com.recoverx.app.ui;

import android.content.Context;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.recoverx.app.R;
import com.recoverx.app.data.PreservedMedia;
import com.recoverx.app.util.AppUtils;

/** Honest status wording for a preserved file. Nothing is ever called "recovered". */
public final class MediaStatus {
    private MediaStatus() {
    }

    public static String shortLabel(Context c, PreservedMedia m) {
        if (m.manuallyMarkedDeleted) return c.getString(R.string.status_marked_by_you);
        if (m.sourceMissing) return c.getString(R.string.status_removed_from_folder, AppUtils.appLabel(m.packageName));
        return c.getString(R.string.status_original_present);
    }

    public static String longExplanation(Context c, PreservedMedia m) {
        StringBuilder b = new StringBuilder();
        if (m.sourceMissing) {
            b.append(c.getString(R.string.status_removed_long, AppUtils.appLabel(m.packageName), AppUtils.formatDateTime(m.sourceMissingAt)));
        } else {
            b.append(c.getString(R.string.status_present_long, AppUtils.appLabel(m.packageName)));
        }
        if (m.manuallyMarkedDeleted) b.append("\n\n").append(c.getString(R.string.status_marked_long));
        return b.toString();
    }

    public static void bindBadge(TextView badge, PreservedMedia m) {
        Context c = badge.getContext();
        badge.setText(shortLabel(c, m));
        if (m.isDeletedRecord()) {
            badge.setBackgroundResource(R.drawable.bg_badge_danger);
            badge.setTextColor(ContextCompat.getColor(c, R.color.danger));
        } else {
            badge.setBackgroundResource(R.drawable.bg_badge_muted);
            badge.setTextColor(ContextCompat.getColor(c, R.color.text_secondary));
        }
    }

    public static String methodLabel(Context c, PreservedMedia m) {
        if (PreservedMedia.METHOD_FOLDER.equals(m.captureMethod)) {
            return c.getString(R.string.method_folder, AppUtils.appLabel(m.packageName));
        }
        return c.getString(R.string.method_notification);
    }

    public static String integrityLabel(Context c, PreservedMedia m) {
        switch (m.integrityStatus == null ? "" : m.integrityStatus) {
            case PreservedMedia.INTEGRITY_OK:
                return m.verifiedAt > 0
                        ? c.getString(R.string.integrity_ok_at, AppUtils.formatDateTime(m.verifiedAt))
                        : c.getString(R.string.integrity_ok_capture);
            case PreservedMedia.INTEGRITY_CHANGED:
                return c.getString(R.string.integrity_changed);
            case PreservedMedia.INTEGRITY_MISSING:
                return c.getString(R.string.integrity_missing);
            default:
                return c.getString(R.string.integrity_unchecked);
        }
    }
}
