package com.recoverx.app.data;

import android.content.Context;
import android.content.SharedPreferences;

/** Small user preferences stored on the phone. */
public final class Prefs {
    public static final String PKG_WHATSAPP = "com.whatsapp";
    public static final String PKG_WHATSAPP_BUSINESS = "com.whatsapp.w4b";
    public static final String PKG_INSTAGRAM = "com.instagram.android";

    /** The only apps RecoverX can ever read. Each one can be switched off in Settings. */
    public static final String[] SUPPORTED_PACKAGES = {PKG_WHATSAPP, PKG_WHATSAPP_BUSINESS, PKG_INSTAGRAM};

    /** Apps whose received media is stored in a folder the user can authorize. */
    public static final String[] MEDIA_FOLDER_PACKAGES = {PKG_WHATSAPP, PKG_WHATSAPP_BUSINESS};

    private static final String FILE = "recoverx_prefs";
    private static final String KEY_ONBOARDED = "onboarded";
    private static final String KEY_AUTO_DETECT = "auto_detect_deleted";
    private static final String KEY_MEDIA = "capture_media";
    private static final String KEY_RETENTION_DAYS = "retention_days";
    private static final String KEY_MAX_STORAGE_MB = "max_storage_mb";
    private static final String KEY_LAST_SCAN = "last_scan";
    private static final String KEY_LAST_SCAN_SUMMARY = "last_scan_summary";

    private Prefs() {
    }

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    public static boolean isOnboarded(Context c) {
        return sp(c).getBoolean(KEY_ONBOARDED, false);
    }

    public static void setOnboarded(Context c) {
        sp(c).edit().putBoolean(KEY_ONBOARDED, true).apply();
    }

    public static boolean isSupported(String packageName) {
        for (String p : SUPPORTED_PACKAGES) if (p.equals(packageName)) return true;
        return false;
    }

    /** Only explicitly supported and enabled packages are ever read. */
    public static boolean isMediaFolderPackage(String packageName) {
        for (String p : MEDIA_FOLDER_PACKAGES) if (p.equals(packageName)) return true;
        return false;
    }

    public static boolean isPackageEnabled(Context c, String packageName) {
        if (!isSupported(packageName)) return false;
        // Instagram is opt-in: nothing from it is read until the user turns it on.
        return sp(c).getBoolean("pkg_" + packageName, !PKG_INSTAGRAM.equals(packageName));
    }

    public static void setPackageEnabled(Context c, String packageName, boolean enabled) {
        sp(c).edit().putBoolean("pkg_" + packageName, enabled).apply();
    }

    public static boolean isAutoDetectDeleted(Context c) {
        return sp(c).getBoolean(KEY_AUTO_DETECT, true);
    }

    public static void setAutoDetectDeleted(Context c, boolean value) {
        sp(c).edit().putBoolean(KEY_AUTO_DETECT, value).apply();
    }

    public static boolean isCaptureMedia(Context c) {
        return sp(c).getBoolean(KEY_MEDIA, true);
    }

    public static void setCaptureMedia(Context c, boolean value) {
        sp(c).edit().putBoolean(KEY_MEDIA, value).apply();
    }

    // ---- Authorized media folders (Storage Access Framework tree URIs) ----

    public static String getMediaTree(Context c, String packageName) {
        return sp(c).getString("tree_" + packageName, null);
    }

    /** Saves the folder and starts preserving files modified from [baselineMillis] onwards. */
    public static void setMediaTree(Context c, String packageName, String treeUri, long baselineMillis) {
        sp(c).edit()
                .putString("tree_" + packageName, treeUri)
                .putLong("baseline_" + packageName, baselineMillis)
                .apply();
    }

    public static void clearMediaTree(Context c, String packageName) {
        sp(c).edit().remove("tree_" + packageName).remove("baseline_" + packageName).apply();
    }

    public static long getBaseline(Context c, String packageName) {
        return sp(c).getLong("baseline_" + packageName, System.currentTimeMillis());
    }

    public static boolean hasAnyMediaTree(Context c) {
        for (String p : MEDIA_FOLDER_PACKAGES) if (getMediaTree(c, p) != null) return true;
        return false;
    }

    /** Days to keep copies whose original still exists. 0 means forever. Removed files are always kept. */
    public static int getRetentionDays(Context c) {
        return sp(c).getInt(KEY_RETENTION_DAYS, 30);
    }

    public static void setRetentionDays(Context c, int days) {
        sp(c).edit().putInt(KEY_RETENTION_DAYS, days).apply();
    }

    public static int getMaxStorageMb(Context c) {
        return sp(c).getInt(KEY_MAX_STORAGE_MB, 1024);
    }

    public static void setMaxStorageMb(Context c, int mb) {
        sp(c).edit().putInt(KEY_MAX_STORAGE_MB, mb).apply();
    }

    public static long getLastScan(Context c) {
        return sp(c).getLong(KEY_LAST_SCAN, 0);
    }

    public static String getLastScanSummary(Context c) {
        return sp(c).getString(KEY_LAST_SCAN_SUMMARY, null);
    }

    public static void setLastScan(Context c, long time, String summary) {
        sp(c).edit().putLong(KEY_LAST_SCAN, time).putString(KEY_LAST_SCAN_SUMMARY, summary).apply();
    }
}
