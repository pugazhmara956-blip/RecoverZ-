package com.recoverx.app.ui;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.graphics.drawable.AnimatedImageDrawable;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.recoverx.app.R;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.data.MessageType;
import com.recoverx.app.data.PreservedMedia;
import com.recoverx.app.media.MediaExporter;
import com.recoverx.app.media.MediaScanner;
import com.recoverx.app.media.ThumbnailLoader;
import com.recoverx.app.util.AppUtils;

import java.io.File;
import java.util.Locale;

/** Preview, play or open one preserved file, with honest status details and actions. */
public class MediaViewerActivity extends AppCompatActivity {

    private static final String EXTRA_ID = "id";

    private PreservedMedia media;
    private MediaPlayer player;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private SeekBar seek;
    private TextView audioTime;
    private MaterialButton playButton;
    private boolean userSeeking;

    private final Runnable progress = new Runnable() {
        @Override
        public void run() {
            if (player != null && !userSeeking) {
                try {
                    seek.setProgress(player.getCurrentPosition());
                    audioTime.setText(time(player.getCurrentPosition()) + " / " + time(player.getDuration()));
                } catch (IllegalStateException ignored) {
                }
            }
            handler.postDelayed(this, 500);
        }
    };

    public static Intent intent(Context c, long id) {
        return new Intent(c, MediaViewerActivity.class).putExtra(EXTRA_ID, id);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media_viewer);
        UiHelper.setupToolbar(this, R.string.media_details);
        long id = getIntent().getLongExtra(EXTRA_ID, -1);
        final Context app = getApplicationContext();
        AppUtils.background(() -> DatabaseHelper.get(app).getMedia(id), m -> {
            if (isFinishing()) return;
            if (m == null) {
                Toast.makeText(app, R.string.media_not_found, Toast.LENGTH_SHORT).show();
                finish();
                return;
            }
            media = m;
            showPreview();
            bindDetails();
            bindActions();
        }, null);
    }

    // ------------------------------------------------------------------ preview

    private void showPreview() {
        File file = new File(media.localPath);
        if (!file.exists()) {
            showError(getString(R.string.file_missing_on_device));
            return;
        }
        String type = media.mediaType;
        String mime = media.mimeType == null ? "" : media.mimeType;
        if (MessageType.IMAGE.equals(type) || (MessageType.GIF.equals(type) && mime.startsWith("image/"))) {
            showImage(file, mime);
        } else if (MessageType.VIDEO.equals(type) || MessageType.GIF.equals(type)) {
            showVideo(file);
        } else if (MessageType.AUDIO.equals(type) || MessageType.VOICE.equals(type)) {
            showAudio(file);
        } else {
            findViewById(R.id.document_box).setVisibility(View.VISIBLE);
            ((TextView) findViewById(R.id.document_name)).setText(media.fileName);
        }
    }

    private void showImage(File file, String mime) {
        ImageView image = findViewById(R.id.preview_image);
        image.setVisibility(View.VISIBLE);
        if (mime.equals("image/gif") && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            try {
                Drawable d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(file));
                image.setImageDrawable(d);
                if (d instanceof AnimatedImageDrawable) ((AnimatedImageDrawable) d).start();
                return;
            } catch (Exception ignored) {
                // fall back to a still frame
            }
        }
        final String path = file.getAbsolutePath();
        AppUtils.background(() -> ThumbnailLoader.decodeSampled(path, 1600), (Bitmap bmp) -> {
            if (bmp != null) image.setImageBitmap(bmp);
            else showError(getString(R.string.preview_failed));
        }, null);
    }

    private void showVideo(File file) {
        VideoView video = findViewById(R.id.preview_video);
        video.setVisibility(View.VISIBLE);
        MediaController controller = new MediaController(this);
        controller.setAnchorView(video);
        video.setMediaController(controller);
        video.setVideoPath(file.getAbsolutePath());
        boolean gif = MessageType.GIF.equals(media.mediaType);
        video.setOnPreparedListener(mp -> {
            mp.setLooping(gif);
            video.seekTo(1);
            if (gif) video.start();
        });
        video.setOnErrorListener((mp, what, extra) -> {
            video.setVisibility(View.GONE);
            showError(getString(R.string.preview_failed));
            return true;
        });
    }

    private void showAudio(File file) {
        findViewById(R.id.audio_box).setVisibility(View.VISIBLE);
        ((ImageView) findViewById(R.id.audio_icon)).setImageResource(MediaCategory.forType(media.mediaType).iconRes);
        seek = findViewById(R.id.audio_seek);
        audioTime = findViewById(R.id.audio_time);
        playButton = findViewById(R.id.btn_audio_play);
        player = new MediaPlayer();
        try {
            player.setDataSource(file.getAbsolutePath());
            player.prepare();
        } catch (Exception e) {
            releasePlayer();
            findViewById(R.id.audio_box).setVisibility(View.GONE);
            showError(getString(R.string.preview_failed));
            return;
        }
        seek.setMax(player.getDuration());
        audioTime.setText(time(0) + " / " + time(player.getDuration()));
        player.setOnCompletionListener(mp -> setPlaying(false));
        playButton.setOnClickListener(v -> {
            if (player == null) return;
            if (player.isPlaying()) {
                player.pause();
                setPlaying(false);
            } else {
                player.start();
                setPlaying(true);
            }
        });
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int value, boolean fromUser) {
                if (fromUser && audioTime != null && player != null) {
                    audioTime.setText(time(value) + " / " + time(player.getDuration()));
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
                userSeeking = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                userSeeking = false;
                if (player != null) player.seekTo(s.getProgress());
            }
        });
        handler.post(progress);
    }

    private void setPlaying(boolean playing) {
        playButton.setText(playing ? R.string.pause : R.string.play);
        playButton.setIconResource(playing ? R.drawable.ic_pause : R.drawable.ic_play);
    }

    private void showError(String text) {
        TextView err = findViewById(R.id.preview_error);
        err.setVisibility(View.VISIBLE);
        err.setText(text);
    }

    private static String time(int ms) {
        int s = Math.max(0, ms / 1000);
        return String.format(Locale.ENGLISH, "%d:%02d", s / 60, s % 60);
    }

    // ------------------------------------------------------------------ details

    private void bindDetails() {
        MediaStatus.bindBadge(findViewById(R.id.status_badge), media);
        ((TextView) findViewById(R.id.status_explain)).setText(MediaStatus.longExplanation(this, media));

        LinearLayout rows = findViewById(R.id.info_rows);
        rows.removeAllViews();
        addRow(rows, R.string.info_file, media.fileName);
        addRow(rows, R.string.info_type, getString(MessageType.label(media.mediaType)) + (media.mimeType != null ? " (" + media.mimeType + ")" : ""));
        addRow(rows, R.string.info_size, AppUtils.formatBytes(media.sizeBytes));
        addRow(rows, R.string.info_source, AppUtils.appLabel(media.packageName));
        addRow(rows, R.string.info_method, MediaStatus.methodLabel(this, media));
        addRow(rows, R.string.info_file_time, AppUtils.formatDateTime(media.sourceModified));
        addRow(rows, R.string.info_captured, AppUtils.formatDateTime(media.capturedAt));
        if (media.sourceMissing) addRow(rows, R.string.info_missing_since, AppUtils.formatDateTime(media.sourceMissingAt));
        if (media.senderGuess != null && !media.senderGuess.isEmpty()) {
            String who = media.senderGuess;
            if (media.conversationGuess != null && !media.conversationGuess.isEmpty() && !media.conversationGuess.equals(media.senderGuess)) {
                who += " (" + media.conversationGuess + ")";
            }
            addRow(rows, R.string.info_sender_guess, who + "\n" + getString(R.string.sender_guess_note));
        } else {
            addRow(rows, R.string.info_sender_guess, getString(R.string.sender_unknown));
        }
        addRow(rows, R.string.info_integrity, MediaStatus.integrityLabel(this, media));
        addRow(rows, R.string.info_sha, media.sha256);

        MaterialButton mark = findViewById(R.id.btn_mark);
        mark.setText(media.manuallyMarkedDeleted ? R.string.unmark_deleted : R.string.mark_deleted);
    }

    private void addRow(LinearLayout parent, int labelRes, String value) {
        View row = LayoutInflater.from(this).inflate(R.layout.item_info_row, parent, false);
        ((TextView) row.findViewById(R.id.info_label)).setText(labelRes);
        ((TextView) row.findViewById(R.id.info_value)).setText(value);
        parent.addView(row);
    }

    // ------------------------------------------------------------------ actions

    private void bindActions() {
        final Context app = getApplicationContext();
        findViewById(R.id.btn_open_with).setOnClickListener(v -> openWith());

        View save = findViewById(R.id.btn_save_phone);
        save.setVisibility(MediaExporter.canSaveToPhone() ? View.VISIBLE : View.GONE);
        save.setOnClickListener(v -> AppUtils.background(() -> MediaExporter.saveToPhone(app, media),
                where -> Toast.makeText(app, getString(R.string.saved_to, where), Toast.LENGTH_LONG).show(),
                e -> Toast.makeText(app, R.string.export_failed, Toast.LENGTH_LONG).show()));

        findViewById(R.id.btn_verify).setOnClickListener(v -> AppUtils.background(() -> MediaScanner.verify(app, media), status -> {
            if (isFinishing()) return;
            bindDetails();
            int msg = PreservedMedia.INTEGRITY_OK.equals(status) ? R.string.verify_ok
                    : PreservedMedia.INTEGRITY_CHANGED.equals(status) ? R.string.integrity_changed : R.string.integrity_missing;
            Toast.makeText(app, msg, Toast.LENGTH_LONG).show();
        }, null));

        findViewById(R.id.btn_mark).setOnClickListener(v -> {
            final boolean newValue = !media.manuallyMarkedDeleted;
            AppUtils.background(() -> {
                DatabaseHelper.get(app).setMediaManuallyDeleted(media.id, newValue);
                return true;
            }, r -> {
                media.manuallyMarkedDeleted = newValue;
                if (!isFinishing()) bindDetails();
            }, null);
        });

        findViewById(R.id.btn_delete).setOnClickListener(v -> new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.delete_saved_copy)
                .setMessage(R.string.delete_saved_copy_body)
                .setPositiveButton(R.string.delete, (d, w) -> {
                    handler.removeCallbacksAndMessages(null);
                    releasePlayer();
                    AppUtils.background(() -> {
                        DatabaseHelper.get(app).deleteMedia(media);
                        return true;
                    }, r -> {
                        Toast.makeText(app, R.string.deleted_copy, Toast.LENGTH_SHORT).show();
                        finish();
                    }, null);
                })
                .setNegativeButton(R.string.cancel, null)
                .show());
    }

    private void openWith() {
        File file = new File(media.localPath);
        if (!file.exists()) {
            Toast.makeText(this, R.string.file_missing_on_device, Toast.LENGTH_SHORT).show();
            return;
        }
        Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".files", file);
        String mime = media.mimeType != null ? media.mimeType : "*/*";
        Intent view = new Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        try {
            startActivity(Intent.createChooser(view, getString(R.string.open_with)));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, R.string.no_app_to_open, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null && player.isPlaying()) {
            player.pause();
            setPlaying(false);
        }
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        releasePlayer();
        super.onDestroy();
    }

    private void releasePlayer() {
        if (player != null) {
            try {
                player.release();
            } catch (Exception ignored) {
            }
            player = null;
        }
    }
}
