package com.recoverx.app.ui;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.recoverx.app.R;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.data.Prefs;
import com.recoverx.app.media.MediaFolders;
import com.recoverx.app.media.MediaScanner;
import com.recoverx.app.media.MediaScheduler;
import com.recoverx.app.util.AppUtils;

/** Authorize WhatsApp media folders, scan, and control storage and deletion. */
public class MediaSetupActivity extends AppCompatActivity {

    private static final int[] RETENTION_DAYS = {7, 30, 90, 365, 0};
    private static final int[] LIMIT_MB = {256, 512, 1024, 2048, 5120};

    private String pendingPackage;
    private LinearLayout folderCards;
    private TextView scanStatus;
    private boolean scanning;

    /** Opens the system folder picker. The user chooses the folder; RecoverX cannot pick it by itself. */
    private final ActivityResultLauncher<Uri> folderPicker = registerForActivityResult(
            new ActivityResultContracts.OpenDocumentTree() {
                @NonNull
                @Override
                public Intent createIntent(@NonNull Context context, Uri input) {
                    Intent i = super.createIntent(context, input);
                    i.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    return i;
                }
            }, this::onFolderPicked);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_media_setup);
        UiHelper.setupToolbar(this, R.string.media_capture_title);
        if (savedInstanceState != null) pendingPackage = savedInstanceState.getString("pending");

        folderCards = findViewById(R.id.folder_cards);
        scanStatus = findViewById(R.id.scan_status);

        MaterialSwitch sw = findViewById(R.id.sw_capture);
        sw.setChecked(Prefs.isCaptureMedia(this));
        sw.setOnCheckedChangeListener((b, on) -> {
            Prefs.setCaptureMedia(this, on);
            MediaScheduler.sync(this);
        });
        findViewById(R.id.row_capture).setOnClickListener(v -> sw.toggle());

        findViewById(R.id.btn_scan_now).setOnClickListener(v -> scanNow());
        findViewById(R.id.row_retention).setOnClickListener(v -> pickRetention());
        findViewById(R.id.row_limit).setOnClickListener(v -> pickLimit());
        findViewById(R.id.btn_delete_all_media).setOnClickListener(v -> confirmDeleteAll());
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("pending", pendingPackage);
    }

    @Override
    protected void onResume() {
        super.onResume();
        bindFolders();
        bindStorage();
        if (!scanning) scanStatus.setText(MediaScanner.lastScanText(this));
    }

    // ------------------------------------------------------------------ folders

    private void bindFolders() {
        folderCards.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(this);
        for (String pkg : Prefs.MEDIA_FOLDER_PACKAGES) {
            View card = inflater.inflate(R.layout.item_folder, folderCards, false);
            ((TextView) card.findViewById(R.id.folder_app)).setText(AppUtils.appLabel(pkg));
            TextView state = card.findViewById(R.id.folder_state);
            TextView path = card.findViewById(R.id.folder_path);
            String tree = Prefs.getMediaTree(this, pkg);
            boolean granted = tree != null && hasPermission(Uri.parse(tree));
            if (granted) {
                state.setText(R.string.folder_authorized);
                state.setBackgroundResource(R.drawable.bg_chip);
                state.setTextColor(ContextCompat.getColor(this, R.color.neon));
                path.setText(getString(R.string.folder_path_since, describeTree(Uri.parse(tree)), AppUtils.formatDateTime(Prefs.getBaseline(this, pkg))));
            } else {
                state.setText(tree == null ? R.string.folder_not_set : R.string.folder_access_lost);
                state.setBackgroundResource(R.drawable.bg_badge_muted);
                state.setTextColor(ContextCompat.getColor(this, tree == null ? R.color.text_secondary : R.color.warning));
                path.setText(getString(R.string.folder_hint, MediaFolders.displayPath(pkg)));
            }
            card.findViewById(R.id.btn_choose_folder).setOnClickListener(v -> {
                pendingPackage = pkg;
                try {
                    folderPicker.launch(MediaFolders.initialUri(pkg));
                } catch (Exception e) {
                    Toast.makeText(this, R.string.picker_failed, Toast.LENGTH_LONG).show();
                }
            });
            View remove = card.findViewById(R.id.btn_remove_folder);
            remove.setEnabled(tree != null);
            remove.setOnClickListener(v -> removeFolder(pkg));
            folderCards.addView(card);
        }
    }

    private boolean hasPermission(Uri tree) {
        for (android.content.UriPermission p : getContentResolver().getPersistedUriPermissions()) {
            if (p.getUri().equals(tree) && p.isReadPermission()) return true;
        }
        return false;
    }

    private static String describeTree(Uri tree) {
        try {
            String id = DocumentsContract.getTreeDocumentId(tree);
            int colon = id.indexOf(':');
            String volume = colon > 0 ? id.substring(0, colon) : "";
            String path = colon >= 0 ? id.substring(colon + 1) : id;
            return ("primary".equals(volume) ? "Internal storage/" : volume + "/") + path;
        } catch (Exception e) {
            return tree.toString();
        }
    }

    private void onFolderPicked(Uri tree) {
        String pkg = pendingPackage;
        pendingPackage = null;
        if (tree == null || pkg == null) return;
        String docId;
        try {
            docId = DocumentsContract.getTreeDocumentId(tree);
        } catch (Exception e) {
            docId = "";
        }
        // Accept only the selected app's own public media folder (or a subfolder of it).
        String expected = "Android/media/" + pkg + "/";
        if (!(docId + "/").contains(expected)) {
            new MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.wrong_folder_title)
                    .setMessage(getString(R.string.wrong_folder_body, AppUtils.appLabel(pkg), MediaFolders.displayPath(pkg)))
                    .setPositiveButton(R.string.ok, null)
                    .show();
            return;
        }
        try {
            getContentResolver().takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (SecurityException e) {
            Toast.makeText(this, R.string.picker_failed, Toast.LENGTH_LONG).show();
            return;
        }
        String old = Prefs.getMediaTree(this, pkg);
        if (old != null && !old.equals(tree.toString())) releaseQuietly(Uri.parse(old));
        // Keep the original start time when the same folder is chosen again.
        long baseline = old != null && old.equals(tree.toString()) ? Prefs.getBaseline(this, pkg) : System.currentTimeMillis();
        Prefs.setMediaTree(this, pkg, tree.toString(), baseline);
        if (!Prefs.isCaptureMedia(this)) {
            Prefs.setCaptureMedia(this, true);
            ((MaterialSwitch) findViewById(R.id.sw_capture)).setChecked(true);
        }
        MediaScheduler.sync(this);
        bindFolders();
        Toast.makeText(this, getString(R.string.folder_saved, AppUtils.appLabel(pkg)), Toast.LENGTH_LONG).show();
    }

    private void removeFolder(String pkg) {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.remove_access)
                .setMessage(getString(R.string.remove_access_body, AppUtils.appLabel(pkg)))
                .setPositiveButton(R.string.remove, (d, w) -> {
                    String tree = Prefs.getMediaTree(this, pkg);
                    if (tree != null) releaseQuietly(Uri.parse(tree));
                    Prefs.clearMediaTree(this, pkg);
                    MediaScheduler.sync(this);
                    bindFolders();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void releaseQuietly(Uri uri) {
        try {
            getContentResolver().releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
        }
    }

    // ------------------------------------------------------------------ scan

    private void scanNow() {
        if (scanning) return;
        if (!Prefs.isCaptureMedia(this)) {
            Toast.makeText(this, R.string.capture_off, Toast.LENGTH_SHORT).show();
            return;
        }
        if (!Prefs.hasAnyMediaTree(this)) {
            Toast.makeText(this, R.string.choose_folder_first, Toast.LENGTH_SHORT).show();
            return;
        }
        scanning = true;
        scanStatus.setText(R.string.scanning);
        findViewById(R.id.btn_scan_now).setEnabled(false);
        final Context app = getApplicationContext();
        AppUtils.background(() -> MediaScanner.scanAll(app), result -> {
            scanning = false;
            if (isFinishing()) return;
            findViewById(R.id.btn_scan_now).setEnabled(true);
            scanStatus.setText(MediaScanner.lastScanText(this));
            bindStorage();
            bindFolders();
        }, e -> {
            scanning = false;
            if (isFinishing()) return;
            findViewById(R.id.btn_scan_now).setEnabled(true);
            scanStatus.setText(R.string.scan_failed);
        });
    }

    // ------------------------------------------------------------------ storage

    private void bindStorage() {
        int days = Prefs.getRetentionDays(this);
        ((TextView) findViewById(R.id.retention_value)).setText(retentionLabel(days));
        ((TextView) findViewById(R.id.limit_value)).setText(limitLabel(Prefs.getMaxStorageMb(this)));
        final Context app = getApplicationContext();
        AppUtils.background(() -> {
            DatabaseHelper db = DatabaseHelper.get(app);
            return new long[]{db.mediaTotal(), db.preservedBytes()};
        }, r -> {
            if (isFinishing()) return;
            ((TextView) findViewById(R.id.usage_text)).setText(getString(R.string.media_usage, r[0], AppUtils.formatBytes(r[1])));
        }, null);
    }

    private String retentionLabel(int days) {
        return days <= 0 ? getString(R.string.retention_forever) : getString(R.string.retention_days, days);
    }

    private String limitLabel(int mb) {
        return mb >= 1024 ? getString(R.string.limit_gb, mb / 1024f) : getString(R.string.limit_mb, mb);
    }

    private void pickRetention() {
        String[] labels = new String[RETENTION_DAYS.length];
        int checked = 1;
        for (int i = 0; i < labels.length; i++) {
            labels[i] = retentionLabel(RETENTION_DAYS[i]);
            if (RETENTION_DAYS[i] == Prefs.getRetentionDays(this)) checked = i;
        }
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.retention_title)
                .setSingleChoiceItems(labels, checked, (d, which) -> {
                    Prefs.setRetentionDays(this, RETENTION_DAYS[which]);
                    bindStorage();
                    d.dismiss();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void pickLimit() {
        String[] labels = new String[LIMIT_MB.length];
        int checked = 2;
        for (int i = 0; i < labels.length; i++) {
            labels[i] = limitLabel(LIMIT_MB[i]);
            if (LIMIT_MB[i] == Prefs.getMaxStorageMb(this)) checked = i;
        }
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.storage_limit_title)
                .setSingleChoiceItems(labels, checked, (d, which) -> {
                    Prefs.setMaxStorageMb(this, LIMIT_MB[which]);
                    bindStorage();
                    d.dismiss();
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void confirmDeleteAll() {
        new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.delete_all_media)
                .setMessage(R.string.delete_all_media_body)
                .setPositiveButton(R.string.delete, (d, w) -> {
                    final Context app = getApplicationContext();
                    AppUtils.background(() -> {
                        DatabaseHelper.get(app).clearAllMedia(app);
                        return true;
                    }, r -> {
                        Toast.makeText(app, R.string.media_cleared, Toast.LENGTH_SHORT).show();
                        if (!isFinishing()) bindStorage();
                    }, null);
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
