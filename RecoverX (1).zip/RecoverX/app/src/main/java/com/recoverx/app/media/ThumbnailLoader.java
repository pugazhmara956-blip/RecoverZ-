package com.recoverx.app.media;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import com.recoverx.app.data.MessageType;
import com.recoverx.app.data.PreservedMedia;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Small in-memory thumbnail loader for local copies. */
public final class ThumbnailLoader {
    private static final LruCache<String, Bitmap> CACHE = new LruCache<String, Bitmap>(16 * 1024 * 1024) {
        @Override
        protected int sizeOf(String key, Bitmap value) {
            return value.getByteCount();
        }
    };
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private ThumbnailLoader() {
    }

    public static boolean hasThumbnail(PreservedMedia m) {
        return MessageType.IMAGE.equals(m.mediaType) || MessageType.VIDEO.equals(m.mediaType) || MessageType.GIF.equals(m.mediaType);
    }

    public static void load(ImageView view, PreservedMedia m, int fallbackRes) {
        String key = m.localPath;
        view.setTag(key);
        Bitmap cached = CACHE.get(key);
        if (cached != null) {
            view.setImageBitmap(cached);
            return;
        }
        view.setImageResource(fallbackRes);
        if (!hasThumbnail(m)) return;
        final boolean video = MessageType.VIDEO.equals(m.mediaType)
                || (MessageType.GIF.equals(m.mediaType) && m.mimeType != null && m.mimeType.startsWith("video/"));
        POOL.execute(() -> {
            Bitmap bmp = video ? videoFrame(key) : decodeSampled(key, 240);
            if (bmp == null) return;
            CACHE.put(key, bmp);
            MAIN.post(() -> {
                if (key.equals(view.getTag())) view.setImageBitmap(bmp);
            });
        });
    }

    public static Bitmap decodeSampled(String path, int target) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(path, o);
            int sample = 1;
            while (o.outWidth / (sample * 2) >= target && o.outHeight / (sample * 2) >= target) sample *= 2;
            o = new BitmapFactory.Options();
            o.inSampleSize = sample;
            return BitmapFactory.decodeFile(path, o);
        } catch (Throwable t) {
            return null;
        }
    }

    private static Bitmap videoFrame(String path) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(path);
            Bitmap frame = r.getFrameAtTime(0);
            if (frame == null) return null;
            int w = frame.getWidth();
            int h = frame.getHeight();
            float scale = 240f / Math.max(1, Math.min(w, h));
            if (scale >= 1f) return frame;
            return Bitmap.createScaledBitmap(frame, Math.round(w * scale), Math.round(h * scale), true);
        } catch (Throwable t) {
            return null;
        } finally {
            try {
                r.release();
            } catch (Exception ignored) {
            }
        }
    }
}
