package com.recoverx.app.media;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.util.Log;

import com.recoverx.app.data.CapturedMessage;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.data.MessageType;
import com.recoverx.app.data.Prefs;
import com.recoverx.app.data.PreservedMedia;
import com.recoverx.app.util.AppUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/**
 * Copies new files from folders the user authorized with the system folder picker.
 * Nothing is read from private app storage, nothing is decrypted and nothing leaves the phone.
 */
public final class MediaScanner {
    private static final String TAG = "MediaScanner";
    private static final long BASELINE_GRACE = 60 * 60 * 1000L;
    private static final int MAX_DEPTH = 2;

    public static class Result {
        public int copied;
        public int duplicates;
        public int newlyMissing;
        public int expiredRemoved;
        public int foldersFailed;
        public boolean storageFull;

        public String summary() {
            StringBuilder b = new StringBuilder();
            b.append(copied).append(copied == 1 ? " new file saved" : " new files saved");
            if (duplicates > 0) b.append(", ").append(duplicates).append(" duplicates skipped");
            if (newlyMissing > 0) b.append(", ").append(newlyMissing).append(" removed from folder");
            if (expiredRemoved > 0) b.append(", ").append(expiredRemoved).append(" old copies cleaned");
            if (storageFull) b.append(". Storage limit reached");
            if (foldersFailed > 0) b.append(". ").append(foldersFailed).append(" folder(s) not accessible, choose again in Media capture");
            return b.toString();
        }
    }

    private static class Entry {
        String docId;
        String name;
        String mime;
        long size;
        long modified;
        String type;
    }

    private static final Object LOCK = new Object();

    private MediaScanner() {
    }

    public static Result scanAll(Context context) {
        synchronized (LOCK) {
            Context app = context.getApplicationContext();
            Result result = new Result();
            if (!Prefs.isCaptureMedia(app)) return result;
            for (String pkg : Prefs.MEDIA_FOLDER_PACKAGES) {
                if (!Prefs.isPackageEnabled(app, pkg)) continue;
                String tree = Prefs.getMediaTree(app, pkg);
                if (tree == null) continue;
                try {
                    scanPackage(app, pkg, Uri.parse(tree), result);
                } catch (SecurityException e) {
                    Log.w(TAG, "Folder permission lost for " + pkg, e);
                    result.foldersFailed++;
                } catch (Exception e) {
                    Log.w(TAG, "Scan failed for " + pkg, e);
                    result.foldersFailed++;
                }
            }
            cleanup(app, result);
            Prefs.setLastScan(app, System.currentTimeMillis(), result.summary());
            return result;
        }
    }

    private static void scanPackage(Context app, String pkg, Uri tree, Result result) throws Exception {
        DatabaseHelper db = DatabaseHelper.get(app);
        long baseline = Prefs.getBaseline(app, pkg) - BASELINE_GRACE;
        String rootId = DocumentsContract.getTreeDocumentId(tree);

        // Find media subfolders. The user may have picked the Media folder or one subfolder directly.
        List<Entry> files = new ArrayList<>();
        Set<String> scannedTypes = new HashSet<>();
        String rootName = queryName(app, tree, rootId);
        String rootType = MediaFolders.typeForFolder(pkg, rootName);
        if (rootType != null) {
            collect(app, tree, rootId, rootType, 0, files);
            scannedTypes.add(rootType);
        } else {
            for (Entry child : list(app, tree, rootId)) {
                if (!DocumentsContract.Document.MIME_TYPE_DIR.equals(child.mime)) continue;
                String type = MediaFolders.typeForFolder(pkg, child.name);
                if (type == null) continue;
                collect(app, tree, child.docId, type, 0, files);
                scannedTypes.add(type);
            }
        }
        if (scannedTypes.isEmpty()) throw new IllegalStateException("No media subfolders found");

        Set<String> present = new HashSet<>();
        Set<String> known = db.knownSourceKeys(pkg);
        long maxBytes = Prefs.getMaxStorageMb(app) * 1024L * 1024L;
        long used = db.preservedBytes();
        File dir = new File(app.getFilesDir(), "preserved");
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create storage folder");

        for (Entry e : files) {
            String key = pkg + "|" + e.docId;
            present.add(key);
            if (known.contains(key)) continue;
            if (e.modified < baseline) continue; // only files that arrived after the folder was authorized
            if (e.size <= 0) continue; // still downloading
            if (used + e.size > maxBytes) {
                result.storageFull = true;
                continue;
            }
            Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, e.docId);
            File tmp = new File(dir, "tmp_" + System.nanoTime());
            String hash;
            try (InputStream in = app.getContentResolver().openInputStream(doc)) {
                if (in == null) continue;
                hash = copyWithHash(in, tmp);
            } catch (Exception ex) {
                Log.w(TAG, "Copy failed: " + e.name, ex);
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
                continue;
            }
            if (db.hasMediaHash(hash)) {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
                db.markSeen(key);
                result.duplicates++;
                continue;
            }
            File target = new File(dir, hash.substring(0, 16) + extensionOf(e.name));
            if (!tmp.renameTo(target)) {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
                continue;
            }
            PreservedMedia m = new PreservedMedia();
            m.packageName = pkg;
            m.sourceKey = key;
            m.fileName = e.name;
            m.mimeType = e.mime;
            m.mediaType = e.type;
            m.sizeBytes = target.length();
            m.sha256 = hash;
            m.localPath = target.getAbsolutePath();
            m.sourceModified = e.modified;
            m.capturedAt = System.currentTimeMillis();
            m.captureMethod = PreservedMedia.METHOD_FOLDER;
            m.integrityStatus = PreservedMedia.INTEGRITY_OK;
            CapturedMessage near = db.findNotificationNear(pkg, notificationTypesFor(e.type), e.modified);
            if (near != null) {
                m.linkedMessageId = near.id;
                m.senderGuess = near.senderName;
                m.conversationGuess = near.conversation;
            }
            if (db.insertMedia(m) != -1) {
                used += m.sizeBytes;
                result.copied++;
            } else {
                //noinspection ResultOfMethodCallIgnored
                target.delete();
            }
        }
        // An empty listing is more likely a temporary read problem than every file being deleted at once.
        if (!files.isEmpty()) result.newlyMissing += db.markSourcesMissing(pkg, present, scannedTypes);
    }

    /** Removes old copies whose original still exists. Copies of removed files are kept until the user deletes them. */
    private static void cleanup(Context app, Result result) {
        int days = Prefs.getRetentionDays(app);
        if (days <= 0) return;
        DatabaseHelper db = DatabaseHelper.get(app);
        long cutoff = System.currentTimeMillis() - days * 24L * 60 * 60 * 1000;
        for (PreservedMedia m : db.expiredMedia(cutoff)) {
            db.deleteMedia(m);
            result.expiredRemoved++;
        }
    }

    /** Recomputes the SHA-256 of the saved copy and compares it with the value stored at capture time. */
    public static String verify(Context context, PreservedMedia m) {
        DatabaseHelper db = DatabaseHelper.get(context);
        File f = new File(m.localPath);
        String status;
        if (!f.exists()) {
            status = PreservedMedia.INTEGRITY_MISSING;
        } else {
            try (InputStream in = new FileInputStream(f)) {
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) md.update(buf, 0, n);
                status = toHex(md.digest()).equals(m.sha256) ? PreservedMedia.INTEGRITY_OK : PreservedMedia.INTEGRITY_CHANGED;
            } catch (Exception e) {
                status = PreservedMedia.INTEGRITY_MISSING;
            }
        }
        db.setIntegrity(m.id, status);
        m.integrityStatus = status;
        return status;
    }

    private static String[] notificationTypesFor(String mediaType) {
        if (MessageType.VOICE.equals(mediaType) || MessageType.AUDIO.equals(mediaType)) {
            return new String[]{MessageType.VOICE, MessageType.AUDIO};
        }
        if (MessageType.GIF.equals(mediaType)) return new String[]{MessageType.GIF, MessageType.VIDEO};
        return new String[]{mediaType};
    }

    private static void collect(Context app, Uri tree, String parentId, String type, int depth, List<Entry> out) {
        for (Entry e : list(app, tree, parentId)) {
            if (DocumentsContract.Document.MIME_TYPE_DIR.equals(e.mime)) {
                if (depth < MAX_DEPTH && !MediaFolders.isSkippedChild(e.name)) collect(app, tree, e.docId, type, depth + 1, out);
                continue;
            }
            if (e.name == null || e.name.startsWith(".")) continue;
            e.type = MessageType.DOCUMENT.equals(type) || type == null ? MessageType.DOCUMENT : type;
            out.add(e);
        }
    }

    private static List<Entry> list(Context app, Uri tree, String parentId) {
        List<Entry> list = new ArrayList<>();
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId);
        String[] cols = {
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED};
        try (Cursor c = app.getContentResolver().query(children, cols, null, null, null)) {
            if (c == null) return list;
            while (c.moveToNext()) {
                Entry e = new Entry();
                e.docId = c.getString(0);
                e.name = c.getString(1);
                e.mime = c.getString(2);
                e.size = c.isNull(3) ? 0 : c.getLong(3);
                e.modified = c.isNull(4) ? 0 : c.getLong(4);
                list.add(e);
            }
        }
        return list;
    }

    private static String queryName(Context app, Uri tree, String docId) {
        Uri doc = DocumentsContract.buildDocumentUriUsingTree(tree, docId);
        try (Cursor c = app.getContentResolver().query(doc, new String[]{DocumentsContract.Document.COLUMN_DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {
        }
        return null;
    }

    private static String copyWithHash(InputStream in, File target) throws Exception {
        MessageDigest md = MessageDigest.getInstance("SHA-256");
        try (DigestInputStream din = new DigestInputStream(in, md); OutputStream out = new FileOutputStream(target)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = din.read(buf)) > 0) out.write(buf, 0, n);
        }
        return toHex(md.digest());
    }

    static String extensionOf(String name) {
        if (name == null) return "";
        int dot = name.lastIndexOf('.');
        if (dot < 0 || name.length() - dot > 6) return "";
        return name.substring(dot).toLowerCase(Locale.ENGLISH);
    }

    private static String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format(Locale.ENGLISH, "%02x", b));
        return sb.toString();
    }

    /** Human-readable last scan line for the UI. */
    public static String lastScanText(Context c) {
        long t = Prefs.getLastScan(c);
        if (t == 0) return "No scan yet";
        return "Last scan " + AppUtils.formatDateTime(t) + ": " + Prefs.getLastScanSummary(c);
    }
}
