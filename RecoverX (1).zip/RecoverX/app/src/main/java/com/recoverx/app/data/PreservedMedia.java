package com.recoverx.app.data;

/** A media file copied from a user-authorized folder into RecoverX's private storage. */
public class PreservedMedia {
    public static final String METHOD_FOLDER = "FOLDER";
    public static final String METHOD_NOTIFICATION = "NOTIFICATION";

    public static final String INTEGRITY_UNCHECKED = "UNCHECKED";
    public static final String INTEGRITY_OK = "OK";
    public static final String INTEGRITY_CHANGED = "CHANGED";
    public static final String INTEGRITY_MISSING = "MISSING";

    public long id;
    public String packageName;
    /** Stable key of the original file: package + document ID inside the authorized folder. */
    public String sourceKey;
    public String fileName;
    public String mimeType;
    public String mediaType;
    public long sizeBytes;
    public String sha256;
    public String localPath;
    /** When the original file was last modified, as reported by Android. */
    public long sourceModified;
    /** When RecoverX made its copy. */
    public long capturedAt;
    public String captureMethod;
    /** True when the original disappeared from the app's media folder after it was copied. */
    public boolean sourceMissing;
    public long sourceMissingAt;
    public boolean manuallyMarkedDeleted;
    public String integrityStatus = INTEGRITY_UNCHECKED;
    public long verifiedAt;
    /** Notification matched by time (may be wrong), or 0. */
    public long linkedMessageId;
    public String senderGuess;
    public String conversationGuess;

    public boolean isDeletedRecord() {
        return sourceMissing || manuallyMarkedDeleted;
    }
}
