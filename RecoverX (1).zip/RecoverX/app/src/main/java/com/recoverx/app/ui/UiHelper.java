package com.recoverx.app.ui;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.chip.Chip;
import com.google.android.material.chip.ChipGroup;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.recoverx.app.R;
import com.recoverx.app.data.CapturedMessage;
import com.recoverx.app.data.DatabaseHelper;
import com.recoverx.app.data.MessageType;
import com.recoverx.app.util.AppUtils;

import java.io.File;

/** Shared UI helpers: toolbar, type filter chips and the message detail dialog. */
public final class UiHelper {

    public interface OnTypeSelected {
        /** Null means "all types". */
        void onSelected(String type);
    }

    private UiHelper() {
    }

    public static void setupToolbar(AppCompatActivity activity, int titleRes) {
        MaterialToolbar toolbar = activity.findViewById(R.id.toolbar);
        toolbar.setTitle(titleRes);
        toolbar.setNavigationOnClickListener(v -> activity.finish());
    }

    /** Fills a chip group with "All" plus every message type. */
    public static void bindTypeChips(Context context, ChipGroup group, OnTypeSelected listener) {
        group.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(context);
        Chip all = (Chip) inflater.inflate(R.layout.item_chip, group, false);
        all.setId(View.generateViewId());
        all.setText(R.string.filter_all);
        all.setTag(null);
        group.addView(all);
        for (String type : MessageType.ALL) {
            Chip chip = (Chip) inflater.inflate(R.layout.item_chip, group, false);
            chip.setId(View.generateViewId());
            chip.setText(MessageType.label(type));
            chip.setTag(type);
            group.addView(chip);
        }
        group.check(all.getId());
        group.setOnCheckedStateChangeListener((g, ids) -> {
            if (ids.isEmpty()) return;
            Chip chip = g.findViewById(ids.get(0));
            listener.onSelected(chip == null ? null : (String) chip.getTag());
        });
    }

    public interface OnChipSelected {
        void onSelected(Object tag);
    }

    /** Fills a single-choice chip group. Tags may be null. */
    public static void bindChips(Context context, ChipGroup group, String[] labels, Object[] tags, int checkedIndex, OnChipSelected listener) {
        group.removeAllViews();
        LayoutInflater inflater = LayoutInflater.from(context);
        int checkedId = View.NO_ID;
        for (int i = 0; i < labels.length; i++) {
            Chip chip = (Chip) inflater.inflate(R.layout.item_chip, group, false);
            chip.setId(View.generateViewId());
            chip.setText(labels[i]);
            chip.setTag(tags[i]);
            group.addView(chip);
            if (i == checkedIndex) checkedId = chip.getId();
        }
        if (checkedId != View.NO_ID) group.check(checkedId);
        group.setOnCheckedStateChangeListener((g, ids) -> {
            if (ids.isEmpty()) return;
            Chip chip = g.findViewById(ids.get(0));
            listener.onSelected(chip == null ? null : chip.getTag());
        });
    }

    /** "All apps" plus each supported app. The tag is the package name, or null for all. */
    public static void bindAppChips(Context context, ChipGroup group, String[] packages, OnChipSelected listener) {
        String[] labels = new String[packages.length + 1];
        Object[] tags = new Object[packages.length + 1];
        labels[0] = context.getString(R.string.filter_all_apps);
        for (int i = 0; i < packages.length; i++) {
            labels[i + 1] = com.recoverx.app.util.AppUtils.appLabel(packages[i]);
            tags[i + 1] = packages[i];
        }
        bindChips(context, group, labels, tags, 0, listener);
    }

    /** Shows a message with copy, mark as deleted and delete actions. */
    public static void showMessageDetail(Activity activity, CapturedMessage m) {
        View view = LayoutInflater.from(activity).inflate(R.layout.dialog_message_detail, null, false);
        String sender = m.senderName == null || m.senderName.isEmpty() ? activity.getString(R.string.unknown_sender) : m.senderName;
        ((TextView) view.findViewById(R.id.detail_from)).setText(activity.getString(R.string.detail_from, sender));
        TextView chat = view.findViewById(R.id.detail_chat);
        if (m.conversation != null && !m.conversation.isEmpty() && !m.conversation.equals(m.senderName)) {
            chat.setText(activity.getString(R.string.detail_chat, m.conversation));
        } else {
            chat.setVisibility(View.GONE);
        }
        ((TextView) view.findViewById(R.id.detail_time)).setText(activity.getString(R.string.detail_time, AppUtils.formatDateTime(m.timestamp)));
        ((TextView) view.findViewById(R.id.detail_type)).setText(activity.getString(R.string.detail_type, activity.getString(MessageType.label(m.messageType))));
        ((TextView) view.findViewById(R.id.detail_app)).setText(activity.getString(R.string.detail_app, AppUtils.appLabel(m.packageName)));
        int statusRes = m.manuallyMarkedDeleted ? R.string.status_marked_deleted
                : m.possiblyDeleted ? R.string.status_possibly_deleted : R.string.status_saved;
        ((TextView) view.findViewById(R.id.detail_status)).setText(activity.getString(R.string.detail_status, activity.getString(statusRes)));
        int recoveryRes = MessageType.HIDDEN.equals(m.messageType) ? R.string.recovery_hidden
                : MessageType.isMedia(m.messageType) && m.mediaPath == null ? R.string.recovery_limited : R.string.recovery_available;
        ((TextView) view.findViewById(R.id.detail_recovery)).setText(recoveryRes);

        String text = m.messageText;
        if (MessageType.isMedia(m.messageType) && m.mediaPath == null) {
            text = text + "\n\n" + activity.getString(R.string.media_not_available);
        }
        ((TextView) view.findViewById(R.id.detail_text)).setText(text);

        ImageView image = view.findViewById(R.id.detail_image);
        if (m.mediaPath != null && new File(m.mediaPath).exists()) {
            image.setImageBitmap(BitmapFactory.decodeFile(m.mediaPath));
            image.setVisibility(View.VISIBLE);
        }

        boolean deleted = m.manuallyMarkedDeleted || m.possiblyDeleted;
        new MaterialAlertDialogBuilder(activity)
                .setView(view)
                .setPositiveButton(R.string.copy, (d, w) -> {
                    ClipboardManager cm = activity.getSystemService(ClipboardManager.class);
                    if (cm != null) {
                        cm.setPrimaryClip(ClipData.newPlainText(sender, m.messageText));
                        Toast.makeText(activity, R.string.copied, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNeutralButton(deleted ? R.string.unmark_deleted : R.string.mark_deleted, (d, w) ->
                        AppUtils.background(() -> {
                            DatabaseHelper.get(activity).setManuallyDeleted(m.id, !deleted);
                            return true;
                        }, null, null))
                .setNegativeButton(R.string.delete, (d, w) -> confirmDelete(activity, m))
                .show();
    }

    private static void confirmDelete(Activity activity, CapturedMessage m) {
        new MaterialAlertDialogBuilder(activity)
                .setTitle(R.string.delete_record_title)
                .setMessage(R.string.delete_record_body)
                .setPositiveButton(R.string.delete, (d, w) -> AppUtils.background(() -> {
                    DatabaseHelper.get(activity).delete(m);
                    return true;
                }, null, null))
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
