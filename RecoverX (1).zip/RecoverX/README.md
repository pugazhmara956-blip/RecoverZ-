# RecoverX – Deleted Message Viewer (Ultimate Edition)

Version 2.0 Ultimate · Java · XML layouts · SQLite · NotificationListenerService · Storage Access Framework · WorkManager · Material Design 3

RecoverX saves the text of WhatsApp, WhatsApp Business and (optionally) Instagram notifications on your phone. Version 2.0 adds **media capture**: if you authorize WhatsApp's media folder with the system folder picker, RecoverX copies new photos, videos, GIFs, voice messages, audio and documents into its private storage. If the original later disappears from that folder, your copy stays.

## What RecoverX does and does not do

- **Notification access only for text.** It never opens WhatsApp's or Instagram's private databases, never breaks encryption, never logs into accounts and has **no internet permission**. Nothing is uploaded.
- **Notifications never contain the original media files.** RecoverX does not claim otherwise. Media is copied only from a folder **you pick yourself** in Android's folder picker (`Android/media/com.whatsapp/WhatsApp/Media`, or the WhatsApp Business equivalent). RecoverX checks that the chosen folder belongs to that app.
- **Only new files.** Files that arrive after you authorize the folder are copied. Files WhatsApp never downloaded, view-once media and files deleted before the next scan cannot be saved.
- **Honest deleted labels.** Android never tells apps that a message was deleted.
  - Text: "Possibly deleted" only when WhatsApp later shows "This message was deleted" from the same sender in the same chat, or "Marked as deleted by you".
  - Media: "Removed from WhatsApp folder" only when the original file disappeared from the authorized folder after RecoverX copied it. The app explains that this may mean delete-for-everyone, deletion by you, storage cleanup or a move, and it cannot tell which. You can also mark a file yourself.
  - Nothing is ever labelled "recovered".
- **Sender of a file is a guess.** WhatsApp file names don't include the sender. RecoverX matches a file to a media notification by time and always shows "Matched by time. This may be wrong."
- **Instagram is text only and off by default.** Instagram does not store direct-message media in any folder other apps can open and does not announce unsent messages, so Instagram items can only be marked as deleted by you.
- Only `com.whatsapp`, `com.whatsapp.w4b` and `com.instagram.android` are read, each switchable in Settings. Banks, OTP senders and every other app are ignored.

## Media capture details

| Step | How |
|---|---|
| Folder access | `ACTION_OPEN_DOCUMENT_TREE` with persisted **read-only** permission (`takePersistableUriPermission`) |
| Folders read | `WhatsApp Images`, `Video`, `Voice Notes` (weekly subfolders), `Audio`, `Documents`, `Animated Gifs`. `Sent`, `Private` and hidden folders such as `.Statuses` are skipped |
| Scheduling | WorkManager periodic job (every 15 minutes, as allowed by Android) plus a one-time scan about 45 seconds after a WhatsApp media notification |
| Copy | Streamed into `files/preserved/` while computing **SHA-256** (`DigestInputStream`) |
| Duplicates | Skipped when the SHA-256 already exists |
| Removed detection | A copy whose source document is no longer listed is marked `source_missing` with the time it was noticed |
| Integrity | "Verify integrity" recomputes SHA-256 and compares it with the stored value |
| Retention | Copies of files **still in WhatsApp** older than 7/30/90/365 days (or never) are cleaned up. Copies of removed files are never deleted automatically |
| Storage cap | 256 MB – 5 GB, default 1 GB |
| Export | One file: "Save to phone" via MediaStore into `Pictures/Movies/Music/Download/RecoverX` (Android 10+). Many files: "Export" into any folder you pick |
| Open | FileProvider (`${applicationId}.files`) with "Open with" |

## Screens

- **Deleted** (bottom tab): Deleted Photos, Deleted Videos (and GIFs), Deleted Audio, Deleted Voice Messages, Deleted Documents, Deleted Text Messages, each with removed and saved counts.
- **Media pages:** search by sender or file name, filter by Removed or All saved, app, and date (Today, 7 or 30 days), plus bulk export.
- **Media viewer:** image or animated GIF preview, video player, audio and voice player with seek bar, document "Open with". Shows status, source app, capture method, file time, copy time, possible sender, integrity and SHA-256, with actions to save, verify, mark or unmark, and delete the copy.
- **Media capture** (Settings, Home or Deleted): authorize or remove folders, Scan now, retention, storage limit, WhatsApp auto-download tip, Instagram limits, and Delete all saved media.
- **Search:** filter by message type, app and date range.

## Database (SQLite, version 2)

- `captured_notifications`: unchanged from version 1 (text records).
- `preserved_media`: id, package_name, source_key (UNIQUE), file_name, mime_type, media_type, size_bytes, sha256 (UNIQUE), local_path, source_modified, captured_at, capture_method, source_missing, source_missing_at, manually_marked_deleted, integrity_status, verified_at, linked_message_id, sender_guess, conversation_guess.
- `seen_sources`: source keys already handled (duplicates or copies you deleted), so they are not copied again. No file content is stored there.

Upgrading from 1.0 keeps all saved messages (the `onUpgrade` step only creates the new tables).

## Permissions

- `BIND_NOTIFICATION_LISTENER_SERVICE` (granted by you in Notification access).
- No storage permission, no internet, no SMS, no accessibility, no root, no hidden APIs. Folder access is granted per folder in the system picker and can be removed at any time.
- Backups (`Backup & Restore`) contain text records only. Use Export for media.

## Building

Upload the project zip to the GitHub repository that already contains the `.github/workflows/main.yml` build workflow, then open **Actions** and download the `app-debug` artifact. Locally, run `./gradlew assembleDebug` (JDK 17, Android SDK 35).

## On Xiaomi / Redmi (HyperOS)

1. If installation is blocked, temporarily turn off Play Protect scanning, install, then turn it back on.
2. App info → ⋮ → **Allow restricted settings**, then grant Notification access.
3. Battery saver: **No restrictions**. Autostart: **On**.
4. In WhatsApp: Settings → Storage and data → Media auto-download → allow the types you want to keep.
5. RecoverX → Deleted → **Set up media capture** → **Choose folder** → select WhatsApp's `Media` folder → **Use this folder** → **Allow**.

Use RecoverX only on your own phone and for your own notifications.
